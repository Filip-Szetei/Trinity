"""The Forgotten Temple: five connected rooms in a linear exploration route."""

from __future__ import annotations

import math

import pygame

from game.entities.enemy import Enemy
from game.settings import HEIGHT, HUD_HEIGHT, WIDTH


class Level01:
    ROOM_WIDTH = 700
    ROOM_COUNT = 5
    WORLD_WIDTH = ROOM_WIDTH * ROOM_COUNT
    WORLD_HEIGHT = HEIGHT
    ROOM_NAMES = (
        "TEMPLE ENTRANCE",
        "THE SEALED HALL",
        "OVERGROWN SANCTUM",
        "GUARDIAN'S CHAMBER",
        "THE INNER SHRINE",
    )
    DOOR_CENTER_Y = 440
    DOOR_HALF_HEIGHT = 90
    COMBAT_ROOM_INDEX = 3
    PLANT_GATE_X = 722
    PLANT_WALL_X_OFFSET = 3
    BOTTOM_WALL_VISUAL_OFFSET = -19
    HORIZONTAL_WALL_STRIPE_ENTRY = 8
    WATER_GATE_X = 1400
    WATER_SOURCE_POSITION = (790, 220)
    WATER_SOURCE_VISUAL_POSITION = WATER_SOURCE_POSITION
    WATER_SOURCE_COLLISION_SIZE = (58, 52)
    WATER_BUTTON_POSITION = (WATER_GATE_X - 44, DOOR_CENTER_Y + 28)
    FIRE_GATE_X = 1900
    FIREPLACE_POSITIONS = ((1815, 340), (1815, 650))
    FIRE_SOURCE_POSITIONS = (
        (480, 178),
        (535, 480),
        (880, 178),
        (1220, 178),
        (1510, 178),
        (1660, 465),
        (1760, 490),
        (2020, 178),
        (2370, 178),
        (2820, 178),
        (3220, 178),
    )
    PLANT_SOURCE_POSITIONS = (
        (650, DOOR_CENTER_Y),
        (1460, 270),
        (1680, 214),
    )
    PUZZLE_GATE_TOP = DOOR_CENTER_Y - DOOR_HALF_HEIGHT
    EXIT_PORTAL_CENTER = (3210, 450)
    EXIT_PORTAL_SIZE = (280, 282)
    EXIT_LIGHT_SECONDS = 2.0
    EXIT_HOLD_SECONDS = 2.0
    EXIT_FADE_SECONDS = 2.0
    EXIT_SIGIL_ANCHORS = {
        "Ignis": (0.5, 0.148),
        "Aqua": (0.202, 0.695),
        "Terra": (0.798, 0.695),
    }
    EXIT_SIGIL_MARKER_RADIUS = 33
    EXIT_LINE_GLOW_THRESHOLD = 48
    EXIT_LINE_GLOW_RADIUS = 137

    def __init__(self, assets=None):
        self.assets = assets
        self.world_bounds = pygame.Rect(0, HUD_HEIGHT, self.WORLD_WIDTH, HEIGHT - HUD_HEIGHT)
        self.walls = self._build_walls()
        self.spawn_points = {
            "Aqua": (155, 330),
            "Ignis": (210, 405),
            "Terra": (155, 480),
        }
        self.enemies = []
        self.puzzle_states = {
            "plant_gate": False,
            "water_gate": False,
            "fire_gate": False,
        }
        self.placed_fire_position = None
        self.fireplace_lit = [True, False]
        self.water_source_position = self.WATER_SOURCE_POSITION
        self.water_source_visual_position = self.WATER_SOURCE_VISUAL_POSITION
        self.water_source_hidden = False
        self.combat_started = False
        self.combat_locked = False
        self.combat_complete = False
        self.combat_players = set()
        portal_x, portal_y = self.EXIT_PORTAL_CENTER
        portal_left = portal_x - self.EXIT_PORTAL_SIZE[0] / 2
        portal_top = portal_y - self.EXIT_PORTAL_SIZE[1] / 2
        self.exit_sigils = {
            name: (
                round(portal_left + anchor[0] * self.EXIT_PORTAL_SIZE[0]),
                round(portal_top + anchor[1] * self.EXIT_PORTAL_SIZE[1]),
            )
            for name, anchor in self.EXIT_SIGIL_ANCHORS.items()
        }
        self.exit_occupants = set()
        self.exit_charge = 0.0
        self.exit_light = 0.0
        self.exit_animation_time = 0.0
        self.exit_sigil_charge = {name: 0.0 for name in self.exit_sigils}
        self.level_completed = False
        self.end_portal_image = (
            pygame.transform.scale(assets.end_portal, self.EXIT_PORTAL_SIZE)
            if assets
            else None
        )
        self.end_portal_line_glow = (
            self._create_exit_line_glow(self.end_portal_image)
            if self.end_portal_image
            else None
        )
        self.floor = assets.create_floor(self.WORLD_WIDTH, self.WORLD_HEIGHT) if assets else None
        self.detail_font = pygame.font.SysFont(None, 18)

    def update(self, dt, players):
        enemy_walls = self.walls + self._puzzle_barriers()
        if self.combat_locked:
            enemy_walls += self._combat_door_rects()
        for enemy in self.enemies:
            enemy.update(dt, players, enemy_walls)

    def update_puzzles(self, dt, players, player_inputs):
        return

    def use_ability(self, player, players=(), controller_input=None):
        if player.health <= 0:
            return False
        controller_input = controller_input or {}
        if player.name == "Aqua":
            if player.carried_ability == "water":
                drop_position = player.ability_object_position or player.position
                player.carried_ability = None
                player.ability_object_position = None
                self.water_source_position = drop_position
                self.water_source_visual_position = (
                    drop_position[0],
                    drop_position[1] + 20,
                )
                self.water_source_hidden = False
                if self._near_point(drop_position, self.WATER_BUTTON_POSITION, 90):
                    self.puzzle_states["water_gate"] = True
                    self.water_source_hidden = True
                return True
            if (
                not self.water_source_hidden
                and self._near(player, self.water_source_position, 140)
            ):
                player.carried_ability = "water"
                player.ability_object_position = self.water_source_position
                self.water_source_hidden = True
                return True
        if player.name == "Ignis":
            if player.carried_ability == "fire":
                aim_x = controller_input.get("aim_x", 0.0)
                aim_y = controller_input.get("aim_y", 0.0)
                if controller_input.get("lt") and (aim_x or aim_y):
                    length = math.hypot(aim_x, aim_y)
                    drop_position = (
                        player.x + aim_x / length * 180,
                        player.y + aim_y / length * 180,
                    )
                else:
                    drop_position = player.ability_object_position or player.position
                player.carried_ability = None
                player.ability_object_position = None
                self.placed_fire_position = drop_position
                for index, fireplace_position in enumerate(self.FIREPLACE_POSITIONS):
                    if (
                        not self.fireplace_lit[index]
                        and self._near_point(drop_position, fireplace_position, 90)
                    ):
                        self.fireplace_lit[index] = True
                        self.puzzle_states["fire_gate"] = all(self.fireplace_lit)
                        break
                return True
            lit_fireplace_nearby = any(
                self.fireplace_lit[index]
                and self._near(player, source, 90)
                for index, source in enumerate(self.FIREPLACE_POSITIONS)
            )
            if lit_fireplace_nearby or any(
                self._near(player, source, 105)
                for source in self.FIRE_SOURCE_POSITIONS
            ):
                for index, fireplace_position in enumerate(self.FIREPLACE_POSITIONS):
                    if (
                        self.fireplace_lit[index]
                        and self._near(player, fireplace_position, 90)
                    ):
                        self.fireplace_lit[index] = False
                        self.puzzle_states["fire_gate"] = all(self.fireplace_lit)
                        break
                player.carried_ability = "fire"
                player.ability_object_position = (player.x, player.y - 28)
                return True
        if (
            player.name == "Terra"
            and any(self._near(player, source, 105) for source in self.PLANT_SOURCE_POSITIONS)
        ):
            if self._near(player, (650, self.DOOR_CENTER_Y), 105):
                self.puzzle_states["plant_gate"] = True
            return True
        return False

    @staticmethod
    def _near(player, position, radius):
        return (player.x - position[0]) ** 2 + (player.y - position[1]) ** 2 <= radius ** 2

    @staticmethod
    def _near_point(point, position, radius):
        return (point[0] - position[0]) ** 2 + (point[1] - position[1]) ** 2 <= radius ** 2

    def _puzzle_barriers(self):
        barriers = []
        if not self.water_source_hidden:
            source_x, source_y = self.water_source_position
            collision_width, collision_height = self.WATER_SOURCE_COLLISION_SIZE
            barriers.append(
                pygame.Rect(
                    source_x - collision_width // 2,
                    source_y - 61,
                    collision_width,
                    collision_height,
                )
            )
        if not self.puzzle_states["plant_gate"]:
            barriers.append(self._gate_rect(self.PLANT_GATE_X))
        if not self.puzzle_states["water_gate"]:
            barriers.append(self._gate_rect(self.WATER_GATE_X))
        if not self.puzzle_states["fire_gate"]:
            barriers.append(self._gate_rect(self.FIRE_GATE_X))
            barriers.extend(self._fire_gate_side_walls())
        return barriers

    def _gate_rect(self, x):
        return pygame.Rect(x - 19, self.PUZZLE_GATE_TOP, 38, self.DOOR_HALF_HEIGHT * 2)

    def update_combat_state(self, players):
        if (
            not self.combat_started
            and len(players) == 3
            and all(self._inside_combat_room(player) for player in players)
        ):
            self.combat_started = True
            self.combat_locked = True
            self.combat_players.update(players)
            enemy_sprites = self.assets.enemy_sprites if self.assets else {}
            self.enemies = [
                Enemy(
                    2300, 330, radius=21, color=(137, 111, 84), health=90,
                    kind="guardian", sprite_frames=enemy_sprites.get("guardian"),
                ),
                Enemy(
                    2500, 535, radius=18, color=(255, 120, 45), health=55,
                    kind="fire", sprite_frames=enemy_sprites.get("fire"),
                ),
                Enemy(
                    2680, 410, radius=20, color=(92, 161, 67), health=70,
                    kind="plant", sprite_frames=enemy_sprites.get("plant"),
                ),
            ]

        if self.combat_locked:
            self.combat_players.update(
                player
                for player in players
                if self.ROOM_WIDTH * self.COMBAT_ROOM_INDEX <= player.x
                < self.ROOM_WIDTH * (self.COMBAT_ROOM_INDEX + 1)
            )

        if self.combat_started and all(enemy.health <= 0 for enemy in self.enemies):
            self.combat_complete = True
            self.combat_locked = False

    def update_exit(self, dt, players):
        self.exit_animation_time += dt
        if self.level_completed:
            return

        occupants = set()
        for player in players:
            target = self.exit_sigils.get(player.name)
            if (
                target
                and player.health > 0
                and (player.x - target[0]) ** 2 + (player.y - target[1]) ** 2 <= 36 ** 2
            ):
                occupants.add(player.name)

        self.exit_occupants = occupants
        for name, charge in self.exit_sigil_charge.items():
            if name in occupants:
                self.exit_sigil_charge[name] = min(
                    1.0, charge + dt / self.EXIT_LIGHT_SECONDS
                )
            else:
                self.exit_sigil_charge[name] = max(
                    0.0, charge - dt / self.EXIT_LIGHT_SECONDS
                )

        if len(players) == 3 and len(occupants) == 3:
            self.exit_charge += dt
            self.exit_light = min(
                1.0,
                self.exit_light + dt / self.EXIT_LIGHT_SECONDS,
            )
            if self.exit_charge >= self.EXIT_HOLD_SECONDS:
                self.level_completed = True
        else:
            self.exit_charge = max(
                0.0,
                self.exit_charge - dt / self.EXIT_FADE_SECONDS,
            )
            self.exit_light = max(
                0.0,
                self.exit_light - dt / self.EXIT_FADE_SECONDS,
            )

    def get_wall_rects_for_player(self, player):
        walls = self.walls + self._puzzle_barriers()
        if self.combat_locked and player in self.combat_players:
            walls += self._combat_door_rects()
        return walls

    def _inside_combat_room(self, player):
        left = self.COMBAT_ROOM_INDEX * self.ROOM_WIDTH + 56
        right = left + self.ROOM_WIDTH - 112
        return left <= player.x <= right

    def _combat_door_rects(self):
        top = self.DOOR_CENTER_Y - self.DOOR_HALF_HEIGHT
        height = self.DOOR_HALF_HEIGHT * 2
        return [
            pygame.Rect(
                boundary * self.ROOM_WIDTH,
                top,
                38,
                height,
            )
            for boundary in (self.COMBAT_ROOM_INDEX, self.COMBAT_ROOM_INDEX + 1)
        ]

    def _build_walls(self):
        top = HUD_HEIGHT
        bottom = HEIGHT
        wall_thickness = 38
        top_wall_depth = (
            self.assets.horizontal_wall_tile.get_height()
            if self.assets
            else wall_thickness
        )
        bottom_wall_top = (
            bottom
            - wall_thickness
            - self.BOTTOM_WALL_VISUAL_OFFSET
        )
        top_collision_depth = top_wall_depth - self.HORIZONTAL_WALL_STRIPE_ENTRY
        walls = [
            pygame.Rect(0, top, self.WORLD_WIDTH, top_collision_depth),
            pygame.Rect(
                0,
                bottom_wall_top,
                self.WORLD_WIDTH,
                wall_thickness + self.BOTTOM_WALL_VISUAL_OFFSET,
            ),
            pygame.Rect(0, top, wall_thickness, bottom - top),
            pygame.Rect(self.WORLD_WIDTH - wall_thickness, top, wall_thickness, bottom - top),
        ]

        for boundary in range(1, self.ROOM_COUNT):
            x = boundary * self.ROOM_WIDTH
            if boundary == 3:
                continue
            if boundary == 1:
                x += self.PLANT_WALL_X_OFFSET
            doorway_top = self.DOOR_CENTER_Y - self.DOOR_HALF_HEIGHT
            doorway_bottom = self.DOOR_CENTER_Y + self.DOOR_HALF_HEIGHT
            walls.extend(
                (
                    pygame.Rect(x, top, wall_thickness, doorway_top - top),
                    pygame.Rect(
                        x,
                        doorway_bottom,
                        wall_thickness,
                        bottom - doorway_bottom,
                    ),
                )
            )

        return walls

    @property
    def wall_rects(self):
        return self.walls

    def draw(self, surface, camera=(0, 0)):
        if self.assets:
            self.assets.draw_floor(surface, camera, self.floor)
            if surface.get_height() > self.floor.get_height():
                pygame.draw.rect(
                    surface,
                    (25, 23, 22),
                    (
                        0,
                        self.floor.get_height(),
                        surface.get_width(),
                        surface.get_height() - self.floor.get_height(),
                    ),
                )
            floor_tint = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
            floor_tint.fill((8, 20, 32, 150))
            surface.blit(floor_tint, (0, 0))
        else:
            surface.fill((77, 69, 60))

        camera_x, camera_y = round(camera[0]), round(camera[1])
        bottom_tile_height = self.assets.horizontal_wall_tile.get_height() if self.assets else 0
        bottom_wall_screen_top = surface.get_height() - bottom_tile_height
        bottom_stone_screen_bottom = (
            bottom_wall_screen_top + self.assets.wall_block_height
            if self.assets
            else surface.get_height()
        )
        for wall in self.walls:
            screen_wall = wall.move(-camera_x, -camera_y)
            bottom_aligned = False
            if (
                wall.width < wall.height
                and wall.bottom == HEIGHT
                and self.assets
            ):
                screen_wall.bottom = bottom_stone_screen_bottom - camera_y
                bottom_aligned = True
            if (
                wall.width >= wall.height
                and wall.top == HEIGHT - 38 - self.BOTTOM_WALL_VISUAL_OFFSET
            ):
                screen_wall.top = bottom_wall_screen_top
            if (
                wall.left == self.ROOM_WIDTH + self.PLANT_WALL_X_OFFSET
                and wall.top == HUD_HEIGHT
                and self.assets
            ):
                screen_wall.height += (
                    self.assets.wall_block_height
                    - self.assets.VERTICAL_WALL_BLOCK_OVERLAP
                )
            if self.assets:
                self.assets.draw_wall(
                    surface,
                    screen_wall,
                    HUD_HEIGHT,
                    (camera_x, camera_y),
                    bottom_aligned,
                    wall.left != 0,
                )

        for wall in self._fire_gate_side_walls():
            screen_wall = wall.move(-camera_x, -camera_y)
            bottom_aligned = False
            if self.assets and wall.bottom == HEIGHT:
                screen_wall.bottom = bottom_stone_screen_bottom - camera_y
                bottom_aligned = True
            if self.assets:
                self.assets.draw_wall(
                    surface,
                    screen_wall,
                    HUD_HEIGHT,
                    (camera_x, camera_y),
                    bottom_aligned,
                )

        self._draw_decorations(surface, camera)
        self._draw_room_landmarks(surface, camera_x, camera_y, camera)
        self._draw_puzzles(surface, camera)
        for enemy in self.enemies:
            if enemy.health <= 0:
                continue
            enemy.draw(surface, camera)
            bar = pygame.Rect(round(enemy.x - 20 - camera_x), round(enemy.y - enemy.radius - 14 - camera_y), 40, 6)
            pygame.draw.rect(surface, (20, 20, 20), bar)
            pygame.draw.rect(surface, (90, 220, 110), (bar.x, bar.y, round(40 * enemy.health / enemy.max_health), bar.height))
            label = self.detail_font.render(
                {"guardian": "Guardian", "fire": "Fire Creature", "plant": "Plant Monster"}[enemy.kind],
                True,
                (245, 220, 180),
            )
            surface.blit(label, label.get_rect(midbottom=(round(enemy.x - camera_x), bar.y - 2)))

        if self.combat_locked:
            text = self.detail_font.render("Defeat every guardian to unseal both exits", True, (255, 215, 150))
            surface.blit(text, text.get_rect(center=(surface.get_width() // 2, HUD_HEIGHT + 22)))
        elif not self.combat_started and self.puzzle_states["fire_gate"]:
            text = self.detail_font.render("Bring all three players into the Guardian's Chamber", True, (255, 215, 150))
            surface.blit(text, text.get_rect(center=(surface.get_width() // 2, HUD_HEIGHT + 22)))
        self._draw_exit(surface, camera)

    def _draw_puzzles(self, surface, camera):
        camera_x, camera_y = round(camera[0]), round(camera[1])

        if not self.puzzle_states["plant_gate"]:
            plant_gate_rect = self._gate_rect(self.PLANT_GATE_X)
            self._draw_green_barrier(surface, plant_gate_rect, camera)
        if not self.water_source_hidden:
            self._draw_interactive(
                surface,
                "water source",
                self.water_source_visual_position,
                (72, 72),
                camera,
            )
        water_switch_position = (
            self.WATER_BUTTON_POSITION[0],
            self.WATER_BUTTON_POSITION[1] + (5 if self.puzzle_states["water_gate"] else 0),
        )
        self._draw_interactive(surface, "water_switch", water_switch_position, (48, 48), camera)
        self._draw_interactive(surface, "ground_flame", (1660, 465), (52, 50), camera)
        for index, position in enumerate(self.FIREPLACE_POSITIONS):
            image = (
                self.assets.fireplace_lit
                if self.fireplace_lit[index]
                else self.assets.fireplace_unlit
            )
            scaled = pygame.transform.scale(image, (76, 100))
            rect = scaled.get_rect(
                midbottom=(
                    round(position[0] - camera_x),
                    round(position[1] - camera_y),
                )
            )
            surface.blit(scaled, rect)
        if self.placed_fire_position and not self.puzzle_states["fire_gate"]:
            fire_x, fire_y = self.placed_fire_position
            pygame.draw.circle(
                surface,
                (255, 164, 50),
                (round(fire_x - camera_x), round(fire_y - camera_y)),
                16,
                3,
            )
        self._draw_puzzle_label(
            surface,
            "Terra: ability clears barrier"
            if not self.puzzle_states["plant_gate"]
            else "Barrier cleared",
            610,
            345,
            camera_x,
            camera_y,
            self.puzzle_states["plant_gate"],
        )
        self._draw_puzzle_label(
            surface,
            "Aqua: ability redirects water" if not self.puzzle_states["water_gate"] else "Water mechanism active",
            1280,
            345,
            camera_x,
            camera_y,
            self.puzzle_states["water_gate"],
        )
        if not self.puzzle_states["fire_gate"]:
            self._draw_puzzle_label(
                surface,
                "Ignis: press 2 / Ability at the fireplaces",
                1770,
                345,
                camera_x,
                camera_y,
                False,
            )
        else:
            self._draw_puzzle_label(surface, "Co-op mechanism unlocked", 1850, 345, camera_x, camera_y, True)

    def _draw_interactive(self, surface, name, center, size, camera):
        if not self.assets or name not in self.assets.interactive:
            return
        image = pygame.transform.scale(self.assets.interactive[name], size)
        rect = image.get_rect(
            midbottom=(round(center[0] - camera[0]), round(center[1] - camera[1]))
        )
        surface.blit(image, rect)

    def _draw_green_barrier(self, surface, gate_rect, camera):
        image = self.assets.interactive.get("greenbarrier")
        if image is None:
            return
        visible_bounds = image.get_bounding_rect(min_alpha=32)
        visible_image = image.subsurface(visible_bounds)
        render_rect = gate_rect.inflate(6, 0)
        barrier = pygame.transform.scale(visible_image, render_rect.size)
        screen_rect = render_rect.move(-round(camera[0]), -round(camera[1]))
        surface.blit(barrier, screen_rect)

    def _fire_gate_side_walls(self):
        x = self.FIRE_GATE_X - 19
        top_height = self.PUZZLE_GATE_TOP - HUD_HEIGHT
        bottom_y = self.DOOR_CENTER_Y + self.DOOR_HALF_HEIGHT
        return (
            pygame.Rect(x, HUD_HEIGHT, 38, top_height),
            pygame.Rect(x, bottom_y, 38, HEIGHT - bottom_y),
        )

    def _draw_puzzle_label(self, surface, text, x, y, camera_x, camera_y, solved):
        color = (173, 235, 155) if solved else (255, 222, 155)
        rendered = self.detail_font.render(text, True, color)
        rect = rendered.get_rect(center=(x - camera_x, y - camera_y))
        backing = rect.inflate(12, 8)
        pygame.draw.rect(surface, (32, 29, 27), backing, border_radius=4)
        surface.blit(rendered, rect)

    def _draw_room_landmarks(self, surface, camera_x, camera_y, camera):
        return

    def _draw_decorations(self, surface, camera):
        if not self.assets:
            return

        for x in (480, 880, 1220, 1510, 2020, 2370, 2820, 3220):
            self.assets.draw_decoration(surface, "torch", (x, 178), (34, 72), camera)

        self.assets.draw_decoration(surface, "brazier", (535, 480), (62, 70), camera)
        self.assets.draw_decoration(surface, "brazier", (1760, 490), (62, 70), camera)
        self.assets.draw_decoration(surface, "flowering_plant", (1460, 270), (56, 48), camera)
        self.assets.draw_decoration(surface, "vines", (1680, 214), (112, 62), camera)
        self.assets.draw_decoration(surface, "stone_bench", (1830, 500), (110, 82), camera)
        self.assets.draw_decoration(surface, "bookshelf", (2900, 370), (78, 74), camera)
        self.assets.draw_decoration(surface, "fountain", (3410, 490), (84, 84), camera)

    def _draw_exit(self, surface, camera):
        camera_x, camera_y = round(camera[0]), round(camera[1])
        center = (
            self.EXIT_PORTAL_CENTER[0] - camera_x,
            self.EXIT_PORTAL_CENTER[1] - camera_y,
        )
        rect = pygame.Rect(
            center[0] - self.EXIT_PORTAL_SIZE[0] // 2,
            center[1] - self.EXIT_PORTAL_SIZE[1] // 2,
            *self.EXIT_PORTAL_SIZE,
        )
        if self.end_portal_image:
            rect = self.end_portal_image.get_rect(center=center)
            surface.blit(self.end_portal_image, rect)
        else:
            pygame.draw.circle(surface, (70, 65, 85), center, 130)

        sigil_colors = {
            "Aqua": (90, 195, 255),
            "Ignis": (255, 142, 70),
            "Terra": (140, 220, 105),
        }
        self._draw_exit_lighting(surface, rect, sigil_colors)

        for name, position in self.exit_sigils.items():
            point = (round(position[0] - camera_x), round(position[1] - camera_y))
            charge = self.exit_sigil_charge[name]
            color = tuple(
                round(100 + (channel - 100) * charge)
                for channel in sigil_colors[name]
            )
            pygame.draw.circle(surface, color, point, self.EXIT_SIGIL_MARKER_RADIUS, 3)
            if charge > 0:
                pygame.draw.circle(surface, color, point, self.EXIT_SIGIL_MARKER_RADIUS + 5, 1)

        instruction = (
            "All three sigils aligned!" if self.level_completed
            else "Stand on your own emblem together"
        )
        text = self.detail_font.render(instruction, True, (240, 225, 180))
        surface.blit(text, text.get_rect(center=(center[0], center[1] + self.EXIT_PORTAL_SIZE[1] // 2 + 19)))
        bar = pygame.Rect(center[0] - 72, center[1] + self.EXIT_PORTAL_SIZE[1] // 2 + 31, 144, 7)
        pygame.draw.rect(surface, (38, 34, 31), bar, border_radius=3)
        if self.exit_charge > 0:
            fill = round(bar.width * min(1.0, self.exit_charge / self.EXIT_HOLD_SECONDS))
            pygame.draw.rect(surface, (220, 195, 112), (bar.x, bar.y, fill, bar.height), border_radius=3)

    def _draw_exit_lighting(self, surface, portal_rect, sigil_colors):
        charges = self.exit_sigil_charge
        if self.exit_light <= 0 and not any(charges.values()):
            return

        light = pygame.Surface(self.EXIT_PORTAL_SIZE)
        light.fill((0, 0, 0))
        width, height = self.EXIT_PORTAL_SIZE
        center = (width // 2, height // 2)
        portal_left = self.EXIT_PORTAL_CENTER[0] - width // 2
        points = {
            name: (
                round(position[0] - portal_left),
                round(position[1] - (self.EXIT_PORTAL_CENTER[1] - height // 2)),
            )
            for name, position in self.exit_sigils.items()
        }

        if self.exit_light > 0:
            wash = tuple(round(channel * 0.16 * self.exit_light) for channel in (255, 190, 75))
            pygame.draw.circle(light, wash, center, 120)

        for name, point in points.items():
            charge = charges[name]
            if charge <= 0:
                continue
            color = sigil_colors[name]
            for radius, strength in ((56, 0.08), (46, 0.15), (36, 0.24), (29, 0.34)):
                glow = tuple(round(channel * strength * charge) for channel in color)
                pygame.draw.circle(light, glow, point, radius)

        if self.exit_light > 0:
            progress = self.exit_light
            gold = tuple(round(channel * 0.66 * progress) for channel in (255, 190, 75))
            triangle = tuple(points[name] for name in ("Ignis", "Aqua", "Terra"))
            for start, end in zip(triangle, triangle[1:] + triangle[:1]):
                pygame.draw.line(light, gold, start, end, 5)

            rim_gold = tuple(round(channel * 0.36 * progress) for channel in (255, 190, 75))
            pygame.draw.circle(light, rim_gold, center, 123, 5)

        line_charge = max(self.exit_light, max(charges.values(), default=0.0) * 0.65)
        if self.end_portal_line_glow and line_charge > 0:
            pulse = 0.78 + 0.22 * (
                0.5 + 0.5 * math.sin(self.exit_animation_time * 4.0)
            )
            glow_strength = round(255 * line_charge * pulse)
            line_glow = self.end_portal_line_glow.copy()
            line_glow.fill(
                (glow_strength, glow_strength, glow_strength),
                special_flags=pygame.BLEND_RGB_MULT,
            )
            light.blit(line_glow, (0, 0), special_flags=pygame.BLEND_RGB_ADD)

        surface.blit(light, portal_rect, special_flags=pygame.BLEND_RGB_ADD)

    @classmethod
    def _create_exit_line_glow(cls, portal_image):
        width, height = portal_image.get_size()
        center = (width // 2, height // 2)
        glow = pygame.Surface((width, height))
        glow.fill((0, 0, 0))
        radius_squared = cls.EXIT_LINE_GLOW_RADIUS ** 2

        for x in range(width):
            for y in range(height):
                dx = x - center[0]
                dy = y - center[1]
                if dx * dx + dy * dy > radius_squared:
                    continue
                red, green, blue, alpha = portal_image.get_at((x, y))
                darkness = cls.EXIT_LINE_GLOW_THRESHOLD - max(red, green, blue)
                if alpha and darkness > 0:
                    strength = min(255, round(255 * darkness / cls.EXIT_LINE_GLOW_THRESHOLD))
                    glow.set_at((x, y), (strength, round(strength * 0.75), round(strength * 0.35)))

        return glow
