"""Launch the three-player elemental co-op prototype."""

from __future__ import annotations

import argparse
import asyncio
import os


def parse_args():
    parser = argparse.ArgumentParser(description="Three-player elemental co-op prototype")
    parser.add_argument("--headless", action="store_true", help="Run with the SDL dummy driver for safe CI validation.")
    parser.add_argument("--keyboard", action="store_true", help="Force keyboard-first controls even when Xbox controllers are connected.")
    return parser.parse_known_args()[0]


if __name__ == "__main__":
    args = parse_args()
    if args.headless:
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")

    if __package__ in (None, ""):
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

    import pygame

    from game.entities.player import Player
    from game.levels.level_manager import LevelManager
    from game.settings import FPS, HEIGHT, JOYSTICK_COUNT_REQUIRED, PLAYER_ORDER, WIDTH
    from game.systems.assets import GameAssets
    from game.systems.controller_manager import ControllerManager
    from game.ui.hud import HUD
    from game.ui.menu import MenuOverlay

    class Game:
        def __init__(self):
            pygame.init()
            pygame.display.set_caption("Trinity")
            self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
            self.clock = pygame.time.Clock()
            self.controller_manager = ControllerManager()
            self.assets = GameAssets()
            pygame.display.set_icon(pygame.transform.scale(self.assets.game_icon, (32, 32)))
            self.level_manager = LevelManager(self.assets)
            self.hud = HUD()
            self.menu = MenuOverlay(self.assets)
            self.keyboard_first = args.keyboard
            self.players = [
                Player(
                    "Aqua",
                    self.level_manager.level.spawn_points["Aqua"],
                    controller_index=0,
                    sprites=self.assets.player_sprites["Aqua"],
                    dead_sprite=self.assets.dead_sprites["Aqua"],
                ),
                Player(
                    "Ignis",
                    self.level_manager.level.spawn_points["Ignis"],
                    controller_index=1,
                    sprites=self.assets.player_sprites["Ignis"],
                    dead_sprite=self.assets.dead_sprites["Ignis"],
                    projectile_sprite=self.assets.ignis_fireball,
                ),
                Player(
                    "Terra",
                    self.level_manager.level.spawn_points["Terra"],
                    controller_index=2,
                    sprites=self.assets.player_sprites["Terra"],
                    dead_sprite=self.assets.dead_sprites["Terra"],
                ),
            ]
            self.active_character_index = 0
            self.running = True
            self.state = "main_menu"
            self.menu_selection = 0
            self.menu_navigation_cooldown = 0.0
            self.controls_return_state = "main_menu"

        def keyboard_input(self, player_index):
            if player_index == 0:
                keys = pygame.key.get_pressed()
                return {
                    "move_x": (keys[pygame.K_d] - keys[pygame.K_a]),
                    "move_y": (keys[pygame.K_s] - keys[pygame.K_w]),
                    "attack": keys[pygame.K_f],
                    "attack_pressed": keys[pygame.K_f],
                    "ability": keys[pygame.K_g],
                    "ability_pressed": keys[pygame.K_g],
                    "interact": keys[pygame.K_h],
                    "interact_pressed": keys[pygame.K_h],
                    "pause": False,
                }
            if player_index == 1:
                keys = pygame.key.get_pressed()
                return {
                    "move_x": (keys[pygame.K_RIGHT] - keys[pygame.K_LEFT]),
                    "move_y": (keys[pygame.K_DOWN] - keys[pygame.K_UP]),
                    "attack": keys[pygame.K_KP1],
                    "attack_pressed": keys[pygame.K_KP1],
                    "ability": keys[pygame.K_KP2],
                    "ability_pressed": keys[pygame.K_KP2],
                    "interact": keys[pygame.K_KP3],
                    "interact_pressed": keys[pygame.K_KP3],
                    "pause": False,
                }
            keys = pygame.key.get_pressed()
            return {
                "move_x": (keys[pygame.K_l] - keys[pygame.K_j]),
                "move_y": (keys[pygame.K_k] - keys[pygame.K_i]),
                "attack": keys[pygame.K_u],
                "attack_pressed": keys[pygame.K_u],
                "ability": keys[pygame.K_o],
                "ability_pressed": keys[pygame.K_o],
                "interact": keys[pygame.K_p],
                "interact_pressed": keys[pygame.K_p],
                "pause": False,
            }

        def handle_events(self):
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.KEYDOWN:
                    self.handle_key(event.key)
                elif event.type == pygame.JOYBUTTONDOWN:
                    self.handle_controller_button(event)
                elif event.type == pygame.JOYHATMOTION:
                    self.handle_controller_hat(event)

        def navigate_menu(self, direction):
            if self.state not in ("main_menu", "pause_menu"):
                return
            options_count = 3 if self.state == "main_menu" else 4
            self.menu_selection = (self.menu_selection + direction) % options_count
            self.menu_navigation_cooldown = 0.18

        def handle_controller_hat(self, event):
            if self.state not in ("main_menu", "pause_menu"):
                return
            if event.value[1] > 0:
                self.navigate_menu(-1)
            elif event.value[1] < 0:
                self.navigate_menu(1)

        def handle_key(self, key):
            if self.state == "level_complete":
                if key in (pygame.K_RETURN, pygame.K_ESCAPE, pygame.K_SPACE):
                    self.state = "main_menu"
                    self.menu_selection = 0
                return

            if self.state == "controls":
                if key in (pygame.K_RETURN, pygame.K_ESCAPE, pygame.K_SPACE):
                    self.state = self.controls_return_state
                return

            if self.state == "playing":
                if key == pygame.K_ESCAPE:
                    self.state = "pause_menu"
                    self.menu_selection = 0
                return

            options_count = 3 if self.state == "main_menu" else 4
            if key in (pygame.K_UP, pygame.K_w):
                self.menu_selection = (self.menu_selection - 1) % options_count
            elif key in (pygame.K_DOWN, pygame.K_s):
                self.menu_selection = (self.menu_selection + 1) % options_count
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                self.activate_menu_selection()
            elif key == pygame.K_ESCAPE and self.state == "pause_menu":
                self.state = "playing"

        def handle_controller_button(self, event):
            if self.state == "level_complete":
                if event.button in (0, 1, 7, 9):
                    self.state = "main_menu"
                    self.menu_selection = 0
                return

            if self.state == "controls":
                if event.button == 1:
                    self.state = self.controls_return_state
                return

            if event.button in (7, 9) and self.state in ("playing", "pause_menu"):
                if self.state == "playing":
                    self.state = "pause_menu"
                    self.menu_selection = 0
                else:
                    self.state = "playing"
                return
            if self.state == "playing":
                return

            if event.button in (11, 12):
                self.navigate_menu(-1 if event.button == 11 else 1)
            elif event.button == 0:
                self.activate_menu_selection()

        def activate_menu_selection(self):
            if self.state == "main_menu":
                if self.menu_selection == 0:
                    self.state = "playing"
                elif self.menu_selection == 1:
                    self.controls_return_state = "main_menu"
                    self.state = "controls"
                else:
                    self.running = False
                return

            if self.menu_selection == 0:
                self.state = "playing"
            elif self.menu_selection == 1:
                self.controls_return_state = "pause_menu"
                self.state = "controls"
            elif self.menu_selection == 2:
                self.state = "main_menu"
                self.menu_selection = 0
            else:
                self.running = False

        def update(self, dt):
            if self.state != "playing":
                self.menu_navigation_cooldown = max(0.0, self.menu_navigation_cooldown - dt)
                if self.menu_navigation_cooldown == 0 and self.state in ("main_menu", "pause_menu"):
                    for controller_index in sorted(self.controller_manager.joysticks):
                        move_y = self.controller_manager.get_input(controller_index)["move_y"]
                        if abs(move_y) >= 0.6:
                            self.navigate_menu(-1 if move_y < 0 else 1)
                            break
                return
            level = self.level_manager.level
            level.update(dt, self.players)
            single_gamepad = not self.keyboard_first and self.controller_manager.connected_count() == 1
            gamepad_index = next(iter(self.controller_manager.joysticks)) if single_gamepad else None
            active_gamepad_input = (
                self.controller_manager.get_input(gamepad_index)
                if single_gamepad
                else None
            )
            if active_gamepad_input and active_gamepad_input["switch_character_pressed"]:
                self.active_character_index = (self.active_character_index + 1) % len(self.players)

            player_inputs = []
            for player_index, player in enumerate(self.players):
                if single_gamepad:
                    if player_index == self.active_character_index:
                        controller_input = active_gamepad_input
                    else:
                        controller_input = self.keyboard_input(player_index)
                elif not self.keyboard_first and player.controller_index in self.controller_manager.joysticks:
                    controller_input = self.controller_manager.get_input(player.controller_index)
                else:
                    controller_input = self.keyboard_input(player_index)
                player_inputs.append(controller_input)
                player.update(
                    dt,
                    controller_input,
                    level.get_wall_rects_for_player(player),
                    level.enemies,
                    level,
                    self.players,
                )

            level.update_puzzles(dt, self.players, player_inputs)

            for downed_player in self.players:
                if downed_player.health > 0:
                    continue
                rescuers = (
                    player
                    for player, controller_input in zip(self.players, player_inputs)
                    if player.health > 0
                    and controller_input["interact"]
                    and (player.x - downed_player.x) ** 2 + (player.y - downed_player.y) ** 2 <= 72 ** 2
                )
                if any(rescuers):
                    downed_player.rescue(dt)
                else:
                    downed_player.interrupt_rescue(dt)

            level.update_combat_state(self.players)
            level.update_exit(dt, self.players)
            if level.level_completed:
                self.state = "level_complete"

        def draw(self):
            camera = self.level_manager.camera_for(self.players)
            self.level_manager.draw(self.screen, camera)
            for player in self.players:
                player.draw(self.screen, self.hud.font, camera)

            missing = self.controller_manager.get_missing_count()
            active_player_index = (
                self.active_character_index
                if not self.keyboard_first and self.controller_manager.connected_count() == 1
                else None
            )
            self.hud.draw(self.screen, self.players, missing, active_player_index)

            if self.state == "main_menu":
                self.menu.draw_main_menu(
                    self.screen,
                    self.menu_selection,
                    self.controller_manager.connected_count(),
                )
            elif self.state == "pause_menu":
                self.menu.draw_pause_menu(self.screen, self.menu_selection)
            elif self.state == "controls":
                self.menu.draw_controls(self.screen, self.controls_return_state == "pause_menu")
            elif self.state == "level_complete":
                self.menu.draw_level_complete(self.screen)

            pygame.display.flip()

        async def run(self):
            while self.running:
                dt = self.clock.tick(FPS) / 1000.0
                self.handle_events()
                self.controller_manager.update()
                self.update(dt)
                self.draw()

                await asyncio.sleep(0)

    game = Game()
    asyncio.run(game.run())
