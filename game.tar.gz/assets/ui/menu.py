"""Minimal menu and overlay helpers."""

from __future__ import annotations

import pygame


class MenuOverlay:
    def __init__(self, assets=None):
        self.assets = assets
        self.title_font = pygame.font.SysFont(None, 78, bold=True)
        self.option_font = pygame.font.SysFont(None, 38)
        self.small_font = pygame.font.SysFont(None, 24)

    def draw_main_menu(self, surface, selected, connected_controllers):
        self._draw_background(surface)
        if self.assets:
            icon = pygame.transform.scale(self.assets.game_icon, (96, 96))
            surface.blit(icon, icon.get_rect(midtop=(surface.get_width() // 2, 22)))
        self._draw_title(surface)
        self._draw_options(surface, ("Play", "Controls", "Quit"), selected, 310)

        controller_text = f"Controllers connected: {connected_controllers}/3"
        self._center_text(surface, controller_text, self.small_font, (185, 210, 225), 530)
        self._center_text(
            surface,
            "Enter / A: Select     Up/Down: Navigate",
            self.small_font,
            (165, 185, 200),
            570,
        )

    def draw_pause_menu(self, surface, selected):
        self._draw_dim(surface)
        self._center_text(surface, "Paused", self.title_font, (255, 255, 255), 190)
        self._draw_options(surface, ("Resume", "Controls", "Main Menu", "Quit"), selected, 310)

    def draw_level_complete(self, surface):
        self._center_text(surface, "LEVEL COMPLETE!", self.title_font, (255, 222, 130), 230)
        self._center_text(surface, "The Forgotten Temple has been restored.", self.option_font, (235, 245, 245), 325)
        self._center_text(surface, "Press A, B, Enter, or Escape to return to the menu", self.small_font, (185, 210, 225), 420)

    def draw_controls(self, surface, return_to_pause=False):
        self._draw_background(surface)
        self._center_text(surface, "Controls", self.title_font, (255, 255, 255), 115)
        lines = (
            "Aqua: move WASD | attack F | ability G | interact H",
            "Ignis: move Arrows | attack NumPad 1 | ability 2 | interact 3",
            "Terra: move IJKL | attack U | ability O | interact P",
            "Escape: pause / return",
            "Single Xbox gamepad: tap RB to switch the active character",
        )
        for index, line in enumerate(lines):
            self._center_text(surface, line, self.small_font, (220, 230, 240), 285 + index * 48)
        self._center_text(
            surface,
            "Press Enter, Escape, or B to return",
            self.small_font,
            (165, 185, 200),
            540,
        )

    def draw_pause_hint(self, surface):
        self._draw_dim(surface, alpha=90)
        self._center_text(surface, "Paused - press Escape to resume", self.option_font, (255, 255, 255), 280)

    def _draw_background(self, surface):
        if self.assets:
            self.assets.draw_floor(surface)
            tint = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
            tint.fill((8, 20, 32, 150))
            surface.blit(tint, (0, 0))
        else:
            surface.fill((16, 27, 40))
            for index in range(12):
                x = 70 + index * 105
                color = (24 + index % 3 * 3, 43 + index % 4 * 3, 57 + index % 3 * 4)
                pygame.draw.circle(surface, color, (x, 600), 130)

    def _draw_title(self, surface):
        self._center_text(surface, "TRINITY", self.title_font, (235, 248, 255), 145)

    def _draw_options(self, surface, options, selected, top):
        for index, option in enumerate(options):
            y = top + index * 58
            is_selected = index == selected
            color = (255, 222, 130) if is_selected else (205, 220, 230)
            text = self.option_font.render(option, True, color)
            rect = text.get_rect(center=(surface.get_width() // 2, y))
            if is_selected:
                backing = rect.inflate(54, 22)
                pygame.draw.rect(surface, (44, 67, 82), backing, border_radius=8)
                pygame.draw.rect(surface, (110, 178, 200), backing, width=2, border_radius=8)
                surface.blit(text, rect)
                marker = self.option_font.render(">", True, color)
                surface.blit(marker, (rect.left - 34, rect.top))
            else:
                surface.blit(text, rect)

    def _draw_dim(self, surface, alpha=190):
        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        overlay.fill((5, 10, 18, alpha))
        surface.blit(overlay, (0, 0))

    @staticmethod
    def _center_text(surface, text, font, color, y):
        rendered = font.render(text, True, color)
        surface.blit(rendered, (surface.get_width() // 2 - rendered.get_width() // 2, y))
