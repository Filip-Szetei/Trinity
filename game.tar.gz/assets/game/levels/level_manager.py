"""Loads and exposes the current test level."""

from __future__ import annotations

from game.levels.level_01 import Level01
from game.settings import WIDTH


class LevelManager:
    def __init__(self, assets=None):
        self.level = Level01(assets)

    @property
    def walls(self):
        return self.level.wall_rects

    def get_wall_rects(self):
        return self.level.wall_rects

    def camera_for(self, players, viewport_width=WIDTH):
        if not players:
            return (0, 0)
        group_center_x = sum(player.x for player in players) / len(players)
        max_camera_x = max(0, self.level.WORLD_WIDTH - viewport_width)
        camera_x = max(0, min(max_camera_x, round(group_center_x - viewport_width / 2)))
        return (camera_x, 0)

    def draw(self, surface, camera=(0, 0)):
        self.level.draw(surface, camera)
