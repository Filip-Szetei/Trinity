"""Player entity with per-controller input and basic actions."""

from __future__ import annotations

import math

import pygame

from game.settings import HUD_HEIGHT, MAX_HEALTH, PLAYER_COLORS
from game.systems.collision import move_with_collision


class Player:
    def __init__(
        self,
        name,
        spawn_position,
        controller_index=0,
        sprite=None,
        sprites=None,
        dead_sprite=None,
        projectile_sprite=None,
        whip_sprite=None,
        scratch_sprite=None,
        bubble_sprite=None,
    ):
        self.name = name
        self.controller_index = controller_index
        self.color = PLAYER_COLORS.get(name, (200, 200, 200))
        self.radius = 18
        source_sprites = sprites or ({"down": sprite} if sprite else {})
        self.sprites = {direction: self._fit_sprite(image) for direction, image in source_sprites.items()}
        self.dead_sprite = self._fit_dead_sprite(dead_sprite) if dead_sprite else None
        self.projectile_sprites = (
            self._fit_projectile_sprite(
                projectile_sprite,
                36 if name == "Aqua" else 24,
            )
            if projectile_sprite
            else {}
        )
        self.whip_sprites = (
            self._fit_whip_sprite(whip_sprite) if whip_sprite else {}
        )
        self.scratch_sprites = (
            self._fit_attack_sprites(scratch_sprite) if scratch_sprite else {}
        )
        self.bubble_sprite = self._fit_bubble_sprite(bubble_sprite) if bubble_sprite else None
        self.facing = "down"
        self.minimum_y = HUD_HEIGHT + max(
            0,
            (66 - self.radius) if self.sprites else self.radius,
        )
        self.x, self.y = spawn_position
        self.prev_x = self.x
        self.prev_y = self.y
        self.speed = 220
        self.health = MAX_HEALTH
        self.max_health = MAX_HEALTH
        self.attack_flash = 0.0
        self.attack_kind = None
        self.ability_flash = 0.0
        self.carried_ability = None
        self.ability_object_position = None
        self.attack_cooldown = 0.0
        self.ability_cooldown = 0.0
        self._ability_input_down = False
        self.projectiles = []
        self.rescue_progress = 0.0
        self.slow_timer = 0.0
        self.element = "fire" if name == "Ignis" else "water" if name == "Aqua" else "plant"
        self.ability_color = {
            "fire": (255, 115, 48),
            "water": (75, 190, 255),
            "plant": (125, 220, 100),
        }[self.element]

    @staticmethod
    def _fit_sprite(image):
        canvas = pygame.Surface((52, 66), pygame.SRCALPHA)
        scale = min(52 / image.get_width(), 66 / image.get_height())
        size = (max(1, round(image.get_width() * scale)), max(1, round(image.get_height() * scale)))
        sprite = pygame.transform.scale(image, size)
        canvas.blit(sprite, ((52 - size[0]) // 2, (66 - size[1]) // 2))
        return canvas

    @staticmethod
    def _fit_dead_sprite(image):
        canvas = pygame.Surface((82, 66), pygame.SRCALPHA)
        scale = min(82 / image.get_width(), 66 / image.get_height())
        size = (max(1, round(image.get_width() * scale)), max(1, round(image.get_height() * scale)))
        sprite = pygame.transform.scale(image, size)
        canvas.blit(sprite, ((82 - size[0]) // 2, (66 - size[1]) // 2))
        return canvas

    @staticmethod
    def _fit_projectile_sprite(image, size):
        scale = min(size / image.get_width(), size / image.get_height())
        fitted_size = (
            max(1, round(image.get_width() * scale)),
            max(1, round(image.get_height() * scale)),
        )
        fitted = pygame.Surface((size, size), pygame.SRCALPHA)
        fitted.blit(
            pygame.transform.scale(image, fitted_size),
            ((size - fitted_size[0]) // 2, (size - fitted_size[1]) // 2),
        )
        return {
            "right": fitted,
            "left": pygame.transform.flip(fitted, True, False),
            "up": pygame.transform.rotate(fitted, 90),
            "down": pygame.transform.rotate(fitted, -90),
        }

    @staticmethod
    def _fit_attack_sprites(image):
        visible_bounds = image.get_bounding_rect(min_alpha=8)
        if not visible_bounds:
            return {}
        visible = image.subsurface(visible_bounds).copy()
        size = 52
        scale = min(size / visible.get_width(), size / visible.get_height())
        fitted_size = (
            max(1, round(visible.get_width() * scale)),
            max(1, round(visible.get_height() * scale)),
        )
        fitted = pygame.transform.scale(visible, fitted_size)
        return {
            "right": fitted,
            "left": pygame.transform.flip(fitted, True, False),
            "up": pygame.transform.rotate(fitted, 90),
            "down": pygame.transform.rotate(fitted, -90),
        }

    @staticmethod
    def _fit_whip_sprite(image):
        visible_bounds = image.get_bounding_rect(min_alpha=8)
        if not visible_bounds:
            return {}
        visible = image.subsurface(visible_bounds).copy()
        scale = min(230 / visible.get_width(), 80 / visible.get_height())
        size = (
            max(1, round(visible.get_width() * scale)),
            max(1, round(visible.get_height() * scale)),
        )
        fitted = pygame.transform.scale(visible, size)
        return {
            "right": fitted,
            "left": pygame.transform.flip(fitted, True, False),
            "up": pygame.transform.rotate(fitted, 90),
            "down": pygame.transform.rotate(fitted, -90),
        }

    @staticmethod
    def _fit_bubble_sprite(image):
        visible_bounds = image.get_bounding_rect(min_alpha=32)
        visible = image.subsurface(visible_bounds)
        size = 52
        scale = min(size / visible.get_width(), size / visible.get_height())
        fitted_size = (
            max(1, round(visible.get_width() * scale)),
            max(1, round(visible.get_height() * scale)),
        )
        return pygame.transform.scale(visible, fitted_size)

    def update(self, dt, controller_input, wall_rects, enemies=(), level=None, players=()):
        if self.health <= 0:
            return

        move_x = controller_input["move_x"]
        move_y = controller_input["move_y"]
        self.slow_timer = max(0.0, self.slow_timer - dt)
        self.attack_cooldown = max(0.0, self.attack_cooldown - dt)
        self.ability_cooldown = max(0.0, self.ability_cooldown - dt)

        if (move_x or move_y) and self.carried_ability != "water":
            if abs(move_x) > abs(move_y):
                self.facing = "right" if move_x > 0 else "left"
            else:
                self.facing = "down" if move_y > 0 else "up"
            length = math.hypot(move_x, move_y)
            if length > 0:
                normalized_x = move_x / length
                normalized_y = move_y / length
                speed = self.speed * (0.55 if self.slow_timer > 0 else 1.0)
                step_x = normalized_x * speed * dt
                step_y = normalized_y * speed * dt
                self.prev_x = self.x
                self.prev_y = self.y
                self.x, self.y = move_with_collision(self, step_x, step_y, wall_rects)
        self.y = max(self.y, self.minimum_y)

        if controller_input["attack_pressed"] and self.attack_cooldown == 0:
            self._attack(enemies)
            self.attack_flash = 0.20
            self.attack_cooldown = 0.9
        ability_down = controller_input.get(
            "ability",
            controller_input.get("ability_pressed", False),
        )
        ability_tapped = (
            controller_input.get("ability_pressed", False)
            and not self._ability_input_down
        )
        self._ability_input_down = ability_down
        carrying_water = self.carried_ability == "water"
        if ability_tapped and (self.ability_cooldown == 0 or carrying_water):
            if level:
                level.use_ability(self, players, controller_input)
            self.ability_flash = 0.35
            if not carrying_water:
                self.ability_cooldown = 1.1

        self.attack_flash = max(0.0, self.attack_flash - dt)
        self.ability_flash = max(0.0, self.ability_flash - dt)
        self._update_ability_object(dt, controller_input, wall_rects)
        self._update_projectiles(dt, enemies, wall_rects)

    def _facing_vector(self):
        return {
            "down": (0, 1),
            "up": (0, -1),
            "right": (1, 0),
            "left": (-1, 0),
        }[self.facing]

    def _attack(self, enemies):
        attack_data = {
            "Aqua": ("projectile", 10, 4),
            "Ignis": ("whip", 6, 8),
            "Terra": ("scratch", 1, 13),
        }
        attack_kind, range_units, damage = attack_data.get(self.name, ("scratch", 1, 13))
        self.attack_kind = attack_kind
        if attack_kind == "projectile":
            direction_x, direction_y = self._facing_vector()
            self.projectiles.append({
                "x": self.x + direction_x * 24,
                "y": self.y + direction_y * 24,
                "dx": direction_x,
                "dy": direction_y,
                "life": 1.0,
                "distance": 0.0,
                "max_distance": range_units * 38,
                "speed": 540,
                "damage": damage,
                "kind": "ice",
            })
            return

        direction_x, direction_y = self._facing_vector()
        for enemy in enemies:
            if enemy.health <= 0:
                continue
            offset_x = enemy.x - self.x
            offset_y = enemy.y - self.y
            forward_distance = offset_x * direction_x + offset_y * direction_y
            side_distance = abs(offset_x * direction_y - offset_y * direction_x)
            if (
                0 <= forward_distance <= range_units * 38
                and side_distance <= self.radius + enemy.radius
            ):
                enemy.take_damage(damage)
                break

    def _update_ability_object(self, dt, controller_input, wall_rects):
        if self.carried_ability is None or self.ability_object_position is None:
            return
        aim_x = controller_input.get("aim_x", 0.0)
        aim_y = controller_input.get("aim_y", 0.0)
        if self.carried_ability == "water" and not (aim_x or aim_y):
            aim_x = controller_input.get("move_x", 0.0)
            aim_y = controller_input.get("move_y", 0.0)
        if abs(aim_x) > 0 or abs(aim_y) > 0:
            length = math.hypot(aim_x, aim_y)
            next_position = (
                self.ability_object_position[0] + aim_x / length * 260 * dt,
                self.ability_object_position[1] + aim_y / length * 260 * dt,
            )
            object_radius = 26
            blocked = any(
                wall.inflate(object_radius * 2, object_radius * 2).collidepoint(
                    next_position
                )
                for wall in wall_rects
            )
            if not blocked:
                self.ability_object_position = next_position
        elif self.carried_ability == "fire":
            direction_x, direction_y = self._facing_vector()
            self.ability_object_position = (
                self.x + direction_x * 34,
                self.y + direction_y * 34,
            )

    def _update_projectiles(self, dt, enemies, wall_rects):
        remaining = []
        for projectile in self.projectiles:
            projectile["life"] -= dt
            travel = projectile["speed"] * dt
            projectile["distance"] += travel
            projectile["x"] += projectile["dx"] * travel
            projectile["y"] += projectile["dy"] * travel
            point = (round(projectile["x"]), round(projectile["y"]))
            if (
                projectile["distance"] >= projectile["max_distance"]
                or any(wall.collidepoint(point) for wall in wall_rects)
            ):
                continue

            hit_enemy = next(
                (
                    enemy
                    for enemy in enemies
                    if enemy.health > 0
                    and math.hypot(enemy.x - point[0], enemy.y - point[1]) <= enemy.radius + 10
                ),
                None,
            )
            if hit_enemy:
                damage = projectile["damage"]
                if projectile["kind"] != "ice":
                    damage = self._elemental_damage(hit_enemy, damage)
                hit_enemy.take_damage(damage)
            elif projectile["life"] > 0:
                remaining.append(projectile)
        self.projectiles = remaining

    def _elemental_damage(self, enemy, damage):
        strong_against = {"Aqua": "fire", "Ignis": "plant", "Terra": "guardian"}
        return round(damage * 1.5) if strong_against.get(self.name) == enemy.kind else damage

    def draw(self, surface, font, camera=(0, 0)):
        draw_x = round(self.x - camera[0])
        draw_y = round(self.y - camera[1])
        if self.health <= 0:
            if self.dead_sprite:
                sprite_rect = self.dead_sprite.get_rect(midbottom=(draw_x, draw_y + self.radius))
                surface.blit(self.dead_sprite, sprite_rect)
            else:
                pygame.draw.ellipse(
                    surface,
                    self.color,
                    pygame.Rect(draw_x - self.radius, draw_y - self.radius, self.radius * 2, self.radius * 2),
                )
            prompt = font.render("DOWN - HOLD INTERACT TO RESCUE", True, (255, 220, 190))
            surface.blit(prompt, prompt.get_rect(midbottom=(draw_x, draw_y - 40)))
            bar = pygame.Rect(draw_x - 25, draw_y - 35, 50, 5)
            pygame.draw.rect(surface, (40, 25, 25), bar)
            pygame.draw.rect(
                surface,
                (245, 180, 95),
                (bar.x, bar.y, round(bar.width * min(1.0, self.rescue_progress / 2.0)), bar.height),
            )
            return

        if self.attack_flash > 0:
            self._draw_attack_effect(surface, draw_x, draw_y)
        if self.ability_flash > 0 and self.name not in ("Aqua", "Ignis"):
            pygame.draw.circle(surface, (255, 255, 200), (draw_x, draw_y), self.radius + 10, 2)
        for projectile in self.projectiles:
            projectile_x = round(projectile["x"] - camera[0])
            projectile_y = round(projectile["y"] - camera[1])
            if projectile["kind"] == "ice" and not self.projectile_sprites:
                points = (
                    (projectile_x, projectile_y - 10),
                    (projectile_x + 7, projectile_y),
                    (projectile_x, projectile_y + 10),
                    (projectile_x - 7, projectile_y),
                )
                pygame.draw.polygon(surface, (165, 235, 255), points)
                pygame.draw.lines(surface, (235, 255, 255), True, points, 2)
            elif self.projectile_sprites:
                direction = (
                    "right" if projectile["dx"] > 0 else
                    "left" if projectile["dx"] < 0 else
                    "down" if projectile["dy"] > 0 else
                    "up"
                )
                sprite = self.projectile_sprites[direction]
                surface.blit(sprite, sprite.get_rect(center=(projectile_x, projectile_y)))
            else:
                pygame.draw.circle(surface, self.ability_color, (projectile_x, projectile_y), 10)
                pygame.draw.circle(surface, (245, 245, 235), (projectile_x, projectile_y), 4)

        if self.carried_ability and self.ability_object_position:
            object_x = round(self.ability_object_position[0] - camera[0])
            object_y = round(self.ability_object_position[1] - camera[1])
            if self.carried_ability == "water":
                if self.bubble_sprite:
                    surface.blit(
                        self.bubble_sprite,
                        self.bubble_sprite.get_rect(center=(object_x, object_y)),
                    )

        current_sprite = self.sprites.get(self.facing)
        if current_sprite:
            sprite_rect = current_sprite.get_rect(midbottom=(draw_x, draw_y + self.radius))
            surface.blit(current_sprite, sprite_rect)
        else:
            body_rect = pygame.Rect(draw_x - self.radius, draw_y - self.radius, self.radius * 2, self.radius * 2)
            pygame.draw.ellipse(surface, self.color, body_rect)
            pygame.draw.circle(surface, (25, 25, 25), (draw_x, draw_y), max(4, self.radius // 3))
        if self.carried_ability == "fire":
            pygame.draw.polygon(
                surface,
                (255, 132, 38),
                ((draw_x - 12, draw_y - 38), (draw_x, draw_y - 68), (draw_x + 12, draw_y - 38)),
            )
            pygame.draw.polygon(
                surface,
                (255, 229, 115),
                ((draw_x - 6, draw_y - 40), (draw_x, draw_y - 61), (draw_x + 6, draw_y - 40)),
            )

    def _draw_attack_effect(self, surface, draw_x, draw_y):
        direction_x, direction_y = self._facing_vector()
        if self.attack_kind == "whip":
            sprite = self.whip_sprites.get(self.facing)
            if sprite:
                progress = 1.0 - self.attack_flash / 0.20
                swing = math.sin(progress * math.pi) * 14
                pulse = 0.92 + math.sin(progress * math.pi) * 0.08
                animated = pygame.transform.rotozoom(sprite, swing, pulse)
                attack_center = (
                    draw_x + direction_x * 106,
                    draw_y + direction_y * 106,
                )
                surface.blit(animated, animated.get_rect(center=attack_center))
                return
            end = (
                draw_x + direction_x * 228,
                draw_y + direction_y * 228,
            )
            pygame.draw.line(surface, (255, 145, 55), (draw_x, draw_y), end, 5)
            pygame.draw.line(surface, (255, 235, 125), (draw_x, draw_y), end, 2)
            pygame.draw.circle(surface, (255, 195, 85), end, 7)
        elif self.attack_kind == "scratch":
            sprite = self.scratch_sprites.get(self.facing)
            if sprite:
                attack_center = (
                    draw_x + direction_x * (self.radius + 22),
                    draw_y + direction_y * (self.radius + 22),
                )
                surface.blit(sprite, sprite.get_rect(center=attack_center))
                return
            center_x = draw_x + direction_x * 30
            center_y = draw_y + direction_y * 30
            pygame.draw.line(
                surface,
                (210, 255, 180),
                (center_x - direction_y * 13 - direction_x * 10, center_y + direction_x * 13 - direction_y * 10),
                (center_x + direction_y * 13 + direction_x * 10, center_y - direction_x * 13 - direction_y * 10),
                3,
            )
            pygame.draw.line(
                surface,
                (150, 235, 120),
                (center_x - direction_y * 13, center_y + direction_x * 13),
                (center_x + direction_y * 13, center_y - direction_x * 13),
                3,
            )

    def take_damage(self, amount):
        self.health = max(0, self.health - amount)
        if self.health == 0:
            self.projectiles.clear()

    def rescue(self, dt):
        if self.health > 0:
            return False
        self.rescue_progress += dt
        if self.rescue_progress < 2.0:
            return False
        self.health = self.max_health // 2
        self.rescue_progress = 0.0
        return True

    def interrupt_rescue(self, dt):
        self.rescue_progress = max(0.0, self.rescue_progress - dt)


    @property
    def position(self):
        return (self.x, self.y)
