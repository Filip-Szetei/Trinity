# /// script
# dependencies = ["pygame_ce"]
# ///
from pathlib import Path
import runpy


runpy.run_path(str(Path(__file__).parent / "game" / "main.py"), run_name="__main__")
