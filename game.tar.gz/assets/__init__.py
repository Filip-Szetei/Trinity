"""Elemental co-op game prototype."""

__all__ = ["main"]
