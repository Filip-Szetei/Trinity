"""Heads-up display for player health and controller status."""

from __future__ import annotations

import pygame

from game.settings import HEIGHT, HUD_HEIGHT, WIDTH


class HUD:
    def __init__(self):
        self.font = pygame.font.SysFont(None, 24)
        self.small_font = pygame.font.SysFont(None, 18)

    def draw(
        self,
        surface,
        players,
        missing_controllers,
        active_player_index=None,
        level=None,
        minimap_expanded=False,
    ):
        panel = pygame.Rect(0, 0, surface.get_width(), HUD_HEIGHT)
        pygame.draw.rect(surface, (15, 19, 25), panel)
        pygame.draw.line(
            surface,
            (120, 120, 120),
            (0, HUD_HEIGHT),
            (surface.get_width(), HUD_HEIGHT),
            2,
        )

        box_width = (surface.get_width() - 80) // 3
        for index, player in enumerate(players):
            box = pygame.Rect(20 + index * (box_width + 20), 18, box_width, 60)
            pygame.draw.rect(surface, (35, 42, 52), box)
            if index == active_player_index:
                pygame.draw.rect(surface, (255, 213, 112), box, width=2)
            pygame.draw.rect(surface, player.color, (box.x + 10, box.y + 11, 16, 16))
            player_name = self.font.render(player.name, True, (250, 250, 250))
            surface.blit(player_name, (box.x + 35, box.y + 8))

            label = "ACTIVE" if index == active_player_index else f"Pad {player.controller_index + 1}"
            label_color = (255, 213, 112) if index == active_player_index else (180, 220, 255)
            controller_label = self.small_font.render(label, True, label_color)
            surface.blit(controller_label, (box.x + 180, box.y + 10))

            health_bar_width = min(180, max(110, box.width - 90))
            health_bar_x = box.x + 10
            health_bar_y = box.y + 35
            pygame.draw.rect(
                surface,
                (80, 80, 80),
                (health_bar_x, health_bar_y, health_bar_width, 12),
            )
            pygame.draw.rect(
                surface,
                (110, 220, 115),
                (
                    health_bar_x,
                    health_bar_y,
                    int((player.health / player.max_health) * health_bar_width),
                    12,
                ),
            )
            health_text = self.small_font.render(
                f"HP {int(player.health)}", True, (245, 245, 245)
            )
            surface.blit(
                health_text,
                (health_bar_x + health_bar_width + 10, box.y + 30),
            )

        if level is not None:
            self.draw_minimap(surface, players, level, minimap_expanded)

    def draw_minimap(self, surface, players, level, expanded=False):
        map_width = 620 if expanded else 220
        map_height = 230 if expanded else 82
        map_rect = (
            pygame.Rect(
                (surface.get_width() - map_width) // 2,
                (surface.get_height() - map_height) // 2,
                map_width,
                map_height,
            )
            if expanded
            else pygame.Rect(
                surface.get_width() - map_width - 18,
                HUD_HEIGHT + 12,
                map_width,
                map_height,
            )
        )
        panel = pygame.Surface(map_rect.size, pygame.SRCALPHA)
        panel.fill((12, 18, 24, 210))
        pygame.draw.rect(panel, (92, 132, 142), panel.get_rect(), width=1, border_radius=7)

        world_width = getattr(level, "WORLD_WIDTH", WIDTH)
        world_height = getattr(level, "WORLD_HEIGHT", HEIGHT)
        room_width = getattr(level, "ROOM_WIDTH", world_width // 5)
        room_count = getattr(level, "ROOM_COUNT", 5)
        content = panel.get_rect().inflate(-16, -16)

        active_players = [player for player in players if player.health > 0]
        center_x = (
            sum(player.x for player in active_players) / len(active_players)
            if active_players
            else world_width / 2
        )
        center_y = (
            sum(player.y for player in active_players) / len(active_players)
            if active_players
            else world_height / 2
        )
        view_width = world_width if expanded else min(world_width, 1400)
        view_height = world_height if expanded else min(world_height, 796)
        view_left = 0 if expanded else max(
            0,
            min(world_width - view_width, center_x - view_width / 2),
        )
        view_top = 0 if expanded else max(
            0,
            min(world_height - view_height, center_y - view_height / 2),
        )

        def world_to_map(x, y):
            return (
                content.left + round(((x - view_left) / view_width) * content.width),
                content.top + round(((y - view_top) / view_height) * content.height),
            )

        room_outline = (118, 155, 161)
        wall_outline = (72, 112, 124)
        outer = pygame.Rect(content)
        pygame.draw.rect(panel, room_outline, outer, width=1)

        doorway_top = getattr(level, "PUZZLE_GATE_TOP", 350)
        doorway_bottom = getattr(level, "PUZZLE_GATE_TOP", 350) + 180

        for boundary in range(1, room_count):
            x = boundary * room_width
            if boundary == 1:
                x += getattr(level, "PLANT_WALL_X_OFFSET", 0)
            sx = world_to_map(x, 0)[0]
            top_sx = world_to_map(x, doorway_top)[1]
            bottom_sx = world_to_map(x, doorway_bottom)[1]
            pygame.draw.line(panel, wall_outline, (sx, content.top), (sx, top_sx), 2)
            pygame.draw.line(panel, wall_outline, (sx, bottom_sx), (sx, content.bottom), 2)

        passage_locks = []
        puzzle_states = getattr(level, "puzzle_states", {})
        if not puzzle_states.get("plant_gate", True):
            passage_locks.append(getattr(level, "PLANT_GATE_X", 722))
        if not puzzle_states.get("water_gate", True):
            passage_locks.append(getattr(level, "WATER_GATE_X", 1400))
        if not puzzle_states.get("fire_gate", True):
            passage_locks.append(getattr(level, "FIRE_GATE_X", 1900))
        if getattr(level, "combat_locked", False):
            combat_room_index = getattr(level, "COMBAT_ROOM_INDEX", 3)
            room_width = getattr(level, "ROOM_WIDTH", world_width // 5)
            passage_locks.extend(
                (
                    combat_room_index * room_width,
                    (combat_room_index + 1) * room_width,
                )
            )

        for passage_x in passage_locks:
            lock_x = world_to_map(passage_x, 0)[0]
            lock_y = world_to_map(0, getattr(level, "DOOR_CENTER_Y", 440))[1]
            pygame.draw.rect(panel, (220, 189, 125), (lock_x - 4, lock_y - 1, 8, 7), border_radius=2)
            pygame.draw.arc(
                panel,
                (220, 189, 125),
                pygame.Rect(lock_x - 3, lock_y - 7, 6, 8),
                0,
                3.14,
                2,
            )

        for player in players:
            if player.health <= 0:
                continue
            px, py = world_to_map(player.x, player.y)
            pygame.draw.circle(panel, player.color, (px, py), 4)
            pygame.draw.circle(panel, (245, 245, 235), (px, py), 4, 1)

        surface.blit(panel, map_rect.topleft)
