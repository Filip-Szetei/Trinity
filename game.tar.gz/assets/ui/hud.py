"""Heads-up display for player health and controller status."""

from __future__ import annotations

import pygame

from game.settings import HEIGHT, HUD_HEIGHT, WIDTH


class HUD:
    def __init__(self):
        self.font = pygame.font.SysFont(None, 24)
        self.small_font = pygame.font.SysFont(None, 18)

    def draw(self, surface, players, missing_controllers, active_player_index=None):
        panel = pygame.Rect(0, 0, WIDTH, HUD_HEIGHT)
        pygame.draw.rect(surface, (15, 19, 25), panel)
        pygame.draw.line(surface, (120, 120, 120), (0, HUD_HEIGHT), (WIDTH, HUD_HEIGHT), 2)

        for index, player in enumerate(players):
            box = pygame.Rect(20 + index * 400, 18, 360, 60)
            pygame.draw.rect(surface, (35, 42, 52), box)
            if index == active_player_index:
                pygame.draw.rect(surface, (255, 213, 112), box, width=2)
            pygame.draw.rect(surface, player.color, (box.x + 10, box.y + 11, 16, 16))
            player_name = self.font.render(player.name, True, (250, 250, 250))
            surface.blit(player_name, (box.x + 35, box.y + 8))

            label = "ACTIVE" if index == active_player_index else f"Pad {player.controller_index + 1}"
            label_color = (255, 213, 112) if index == active_player_index else (180, 220, 255)
            controller_label = self.small_font.render(label, True, label_color)
            surface.blit(controller_label, (box.x + 180, box.y + 10))

            pygame.draw.rect(surface, (80, 80, 80), (box.x + 10, box.y + 35, 110, 12))
            pygame.draw.rect(surface, (110, 220, 115), (box.x + 10, box.y + 35, int((player.health / player.max_health) * 110), 12))
            health_text = self.small_font.render(f"HP {int(player.health)}", True, (245, 245, 245))
            surface.blit(health_text, (box.x + 130, box.y + 30))
