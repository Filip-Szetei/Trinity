"""Temple enemies with distinct melee, ranged, and slowing attacks."""

from __future__ import annotations

import pygame
import math

from game.settings import HUD_HEIGHT
from game.systems.collision import move_with_collision


class Enemy:
    def __init__(
        self,
        x,
        y,
        radius=16,
        color=(180, 70, 70),
        health=60,
        kind="guardian",
        sprite_frames=None,
    ):
        self.x = x
        self.kind = kind
        self.sprite_frames = sprite_frames
        self.radius = radius
        self.min_y = HUD_HEIGHT + radius
        self.y = max(y, self.min_y)
        self.color = color
        self.health = health
        self.max_health = health
        self.speed = 78
        self.attack_cooldown = 0.0
        self.attack_flash = 0.0
        self.projectiles = []
        self.animation_time = 0.0

    def draw(self, surface, camera=(0, 0)):
        if self.health <= 0:
            return
        x = round(self.x - camera[0])
        y = round(self.y - camera[1])
        pygame.draw.circle(surface, (75, 36, 42), (x, y + 4), self.radius + 2)
        if self.sprite_frames:
            frame = self.sprite_frames[int(self.animation_time * 8) % len(self.sprite_frames)]
            frame_size = self.radius * 3
            scale = frame_size / max(frame.get_size())
            size = (
                max(1, round(frame.get_width() * scale)),
                max(1, round(frame.get_height() * scale)),
            )
            sprite = pygame.transform.scale(frame, size)
            surface.blit(sprite, sprite.get_rect(center=(x, y)))
        elif self.kind == "plant":
            pygame.draw.circle(surface, (56, 111, 58), (x, y), self.radius + 3)
            for angle in range(0, 360, 90):
                leaf = (x + round(math.cos(math.radians(angle)) * (self.radius + 5)), y + round(math.sin(math.radians(angle)) * (self.radius + 5)))
                pygame.draw.circle(surface, (112, 184, 78), leaf, 7)
        elif self.kind == "fire":
            pygame.draw.circle(surface, (255, 104, 35), (x, y), self.radius + 2)
            pygame.draw.circle(surface, (255, 198, 76), (x, y), self.radius - 4)
        else:
            pygame.draw.circle(surface, self.color, (x, y), self.radius)
        pygame.draw.circle(surface, (255, 208, 155), (x, y), 5)
        pygame.draw.circle(surface, (40, 20, 25), (x - 6, y - 4), 3)
        pygame.draw.circle(surface, (40, 20, 25), (x + 6, y - 4), 3)
        if self.attack_flash > 0:
            pygame.draw.circle(surface, (255, 100, 75), (x, y), self.radius + 8, 2)
        for projectile in self.projectiles:
            px, py = round(projectile["x"] - camera[0]), round(projectile["y"] - camera[1])
            pygame.draw.circle(surface, (255, 89, 29), (px, py), 9)
            pygame.draw.circle(surface, (255, 209, 94), (px, py), 4)

    def update(self, dt, players=(), wall_rects=()):
        self.y = max(self.y, self.min_y)
        self.animation_time += dt
        self.attack_cooldown = max(0.0, self.attack_cooldown - dt)
        self.attack_flash = max(0.0, self.attack_flash - dt)
        if self.health <= 0:
            self.projectiles.clear()
            return

        active_players = [player for player in players if player.health > 0]
        self._update_projectiles(dt, active_players, wall_rects)
        if not active_players or self.health <= 0:
            return

        target = min(
            active_players,
            key=lambda player: (player.x - self.x) ** 2 + (player.y - self.y) ** 2,
        )
        offset_x = target.x - self.x
        offset_y = target.y - self.y
        distance = (offset_x * offset_x + offset_y * offset_y) ** 0.5
        if self.kind == "fire":
            if distance <= 360 and self.attack_cooldown == 0:
                self.projectiles.append({
                    "x": self.x,
                    "y": self.y,
                    "dx": offset_x / max(distance, 1),
                    "dy": offset_y / max(distance, 1),
                    "life": 2.0,
                })
                self.attack_cooldown = 1.8
                self.attack_flash = 0.2
            if distance < 170 or 260 < distance <= 420:
                self.prev_x = self.x
                self.prev_y = self.y
                direction = -1 if distance < 170 else 1
                speed = 48
                step = min(speed * dt, abs(distance - (170 if direction < 0 else 260)))
                self.x, self.y = move_with_collision(
                    self,
                    offset_x / max(distance, 1) * step * direction,
                    offset_y / max(distance, 1) * step * direction,
                    wall_rects,
                )
            return

        if self.kind == "plant" and distance <= 145:
            target.slow_timer = max(target.slow_timer, 0.45)

        if distance <= 36:
            if self.attack_cooldown == 0:
                target.take_damage(12 if self.kind == "plant" else 9)
                self.attack_cooldown = 1.0 if self.kind == "plant" else 0.9
                self.attack_flash = 0.18
            return

        detection_range = 420 if self.kind == "plant" else 300
        if distance <= detection_range:
            self.prev_x = self.x
            self.prev_y = self.y
            speed = {"guardian": 62, "plant": 88}.get(self.kind, 78)
            step = min(speed * dt, distance - 34)
            self.x, self.y = move_with_collision(
                self,
                offset_x / distance * step,
                offset_y / distance * step,
                wall_rects,
            )

    def _update_projectiles(self, dt, players, wall_rects):
        remaining = []
        for projectile in self.projectiles:
            projectile["life"] -= dt
            projectile["x"] += projectile["dx"] * 230 * dt
            projectile["y"] += projectile["dy"] * 230 * dt
            point = (round(projectile["x"]), round(projectile["y"]))
            if any(wall.collidepoint(point) for wall in wall_rects):
                continue
            target = next(
                (player for player in players if math.hypot(player.x - point[0], player.y - point[1]) <= player.radius + 9),
                None,
            )
            if target:
                target.take_damage(12)
            elif projectile["life"] > 0:
                remaining.append(projectile)
        self.projectiles = remaining

    def take_damage(self, amount):
        self.health = max(0, self.health - amount)
