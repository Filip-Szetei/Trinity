"""Controller discovery, assignment, and input processing for three local gamepads."""

from __future__ import annotations

import pygame

from game.settings import MOVEMENT_DEADZONE


class ControllerManager:
    def __init__(self):
        pygame.joystick.init()
        self.joysticks = {}
        self.previous_buttons = {}
        self.current_buttons = {}
        self.refresh()

    def refresh(self):
        connected = pygame.joystick.get_count()
        for index in range(connected):
            if index not in self.joysticks:
                joystick = pygame.joystick.Joystick(index)
                joystick.init()
                self.joysticks[index] = joystick
                self.previous_buttons[index] = [False] * max(10, joystick.get_numbuttons())
                self.current_buttons[index] = [False] * max(10, joystick.get_numbuttons())

        for index in list(self.joysticks):
            if index >= connected:
                del self.joysticks[index]
                self.previous_buttons.pop(index, None)
                self.current_buttons.pop(index, None)

    def update(self):
        self.refresh()
        for index, joystick in self.joysticks.items():
            current = [bool(joystick.get_button(button_index)) for button_index in range(joystick.get_numbuttons())]
            self.previous_buttons[index] = self.current_buttons.get(index, [False] * len(current))
            self.current_buttons[index] = current

    def connected_count(self):
        return len(self.joysticks)

    def get_missing_count(self):
        return max(0, 3 - len(self.joysticks))

    def axis_value(self, joystick, index):
        value = joystick.get_axis(index)
        if abs(value) < MOVEMENT_DEADZONE:
            return 0.0
        return value

    def get_input(self, player_index):
        if player_index not in self.joysticks:
            return {
                "move_x": 0.0,
                "move_y": 0.0,
                "attack": False,
                "attack_pressed": False,
                "ability": False,
                "ability_pressed": False,
                "interact": False,
                "interact_pressed": False,
                "switch_character_pressed": False,
                "pause": False,
            }

        joystick = self.joysticks[player_index]
        current = self.current_buttons.get(player_index, [False] * max(10, joystick.get_numbuttons()))
        previous = self.previous_buttons.get(player_index, [False] * len(current))

        def pressed(button_index):
            return bool(current[button_index]) and not previous[button_index] if button_index < len(previous) and button_index < len(current) else False

        move_x = self.axis_value(joystick, 0)
        move_y = self.axis_value(joystick, 1)

        return {
            "move_x": move_x,
            "move_y": move_y,
            "attack": bool(current[0]) if len(current) > 0 else False,
            "attack_pressed": pressed(0),
            "ability": bool(current[2]) if len(current) > 2 else False,
            "ability_pressed": pressed(2),
            "interact": bool(current[3]) if len(current) > 3 else False,
            "interact_pressed": pressed(3),
            "switch_character_pressed": pressed(5),
            "pause": any(current[index] for index in (7, 9) if index < len(current)),
        }
