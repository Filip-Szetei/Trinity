"""Helpers for simple top-down collision logic."""

from __future__ import annotations

import pygame


def collides_with_rect(entity_rect, wall_rects):
    """Return True when the entity rect overlaps any wall rectangle."""
    for wall in wall_rects:
        if entity_rect.colliderect(wall):
            return True
    return False


def move_with_collision(entity, dx, dy, wall_rects):
    """Apply movement in axis-aligned steps while respecting walls."""
    new_x = entity.x + dx
    entity.x = new_x
    entity_rect = pygame.Rect(entity.x - entity.radius, entity.y - entity.radius, entity.radius * 2, entity.radius * 2)
    if collides_with_rect(entity_rect, wall_rects):
        entity.x = entity.prev_x

    new_y = entity.y + dy
    entity.y = new_y
    entity_rect = pygame.Rect(entity.x - entity.radius, entity.y - entity.radius, entity.radius * 2, entity.radius * 2)
    if collides_with_rect(entity_rect, wall_rects):
        entity.y = entity.prev_y

    entity.prev_x = entity.x
    entity.prev_y = entity.y

    return entity.x, entity.y
