"""The Forgotten Temple: five connected rooms in a linear exploration route."""

from __future__ import annotations

import pygame

from game.entities.enemy import Enemy
from game.settings import HEIGHT, HUD_HEIGHT, WIDTH


class Level01:
    ROOM_WIDTH = 700
    ROOM_COUNT = 5
    WORLD_WIDTH = ROOM_WIDTH * ROOM_COUNT
    WORLD_HEIGHT = HEIGHT
    STRUCTURAL_WALL_COUNT = 4 + 2 * (ROOM_COUNT - 1)
    BOTTOM_CORNER_CAP_OFFSET = 48
    ROOM_NAMES = (
        "TEMPLE ENTRANCE",
        "THE SEALED HALL",
        "OVERGROWN SANCTUM",
        "GUARDIAN'S CHAMBER",
        "THE INNER SHRINE",
    )
    DOOR_CENTER_Y = 440
    DOOR_HALF_HEIGHT = 90
    COMBAT_ROOM_INDEX = 3
    PLANT_GATE_X = 700
    WATER_GATE_X = 1400
    FIRE_GATE_X = 1900
    PUZZLE_GATE_TOP = DOOR_CENTER_Y - DOOR_HALF_HEIGHT
    EXIT_PORTAL_CENTER = (3210, 450)
    EXIT_PORTAL_SIZE = (280, 282)
    EXIT_LIGHT_SECONDS = 2.0
    EXIT_HOLD_SECONDS = 2.0
    EXIT_SIGIL_ANCHORS = {
        "Ignis": (0.5, 0.148),
        "Aqua": (0.202, 0.695),
        "Terra": (0.798, 0.695),
    }
    EXIT_SIGIL_MARKER_RADIUS = 33

    def __init__(self, assets=None):
        self.assets = assets
        self.world_bounds = pygame.Rect(0, HUD_HEIGHT, self.WORLD_WIDTH, HEIGHT - HUD_HEIGHT)
        self.walls = self._build_walls()
        self.spawn_points = {
            "Aqua": (155, 330),
            "Ignis": (210, 405),
            "Terra": (155, 480),
        }
        self.enemies = []
        self.puzzle_states = {
            "plant_gate": False,
            "water_gate": False,
            "fire_lit": False,
            "fire_gate": False,
        }
        self.combat_started = False
        self.combat_locked = False
        self.combat_complete = False
        self.combat_players = set()
        portal_x, portal_y = self.EXIT_PORTAL_CENTER
        portal_left = portal_x - self.EXIT_PORTAL_SIZE[0] / 2
        portal_top = portal_y - self.EXIT_PORTAL_SIZE[1] / 2
        self.exit_sigils = {
            name: (
                round(portal_left + anchor[0] * self.EXIT_PORTAL_SIZE[0]),
                round(portal_top + anchor[1] * self.EXIT_PORTAL_SIZE[1]),
            )
            for name, anchor in self.EXIT_SIGIL_ANCHORS.items()
        }
        self.exit_occupants = set()
        self.exit_charge = 0.0
        self.exit_light = 0.0
        self.exit_sigil_charge = {name: 0.0 for name in self.exit_sigils}
        self.level_completed = False
        self.end_portal_image = (
            pygame.transform.scale(assets.end_portal, self.EXIT_PORTAL_SIZE)
            if assets
            else None
        )
        self.floor = assets.create_floor(self.WORLD_WIDTH, self.WORLD_HEIGHT) if assets else None
        self.room_font = pygame.font.SysFont(None, 28, bold=True)
        self.detail_font = pygame.font.SysFont(None, 18)

    def update(self, dt, players):
        enemy_walls = self.walls + self._puzzle_barriers()
        if self.combat_locked:
            enemy_walls += self._combat_door_rects()
        for enemy in self.enemies:
            enemy.update(dt, players, enemy_walls)

    def update_puzzles(self, dt, players, player_inputs):
        if self.puzzle_states["fire_lit"] and not self.puzzle_states["fire_gate"]:
            for player, controller_input in zip(players, player_inputs):
                if (
                    player.health > 0
                    and player.name != "Ignis"
                    and controller_input["interact"]
                    and self._near(player, (1820, 490), 78)
                ):
                    self.puzzle_states["fire_gate"] = True
                    self.puzzle_states["fire_lit"] = False
                    break

    def use_ability(self, player, players=()):
        if player.health <= 0:
            return False
        if (
            player.name == "Terra"
            and not self.puzzle_states["plant_gate"]
            and self._near(player, (650, self.DOOR_CENTER_Y), 105)
        ):
            self.puzzle_states["plant_gate"] = True
            return True
        if (
            player.name == "Aqua"
            and not self.puzzle_states["water_gate"]
            and self._near(player, (1290, self.DOOR_CENTER_Y), 115)
        ):
            self.puzzle_states["water_gate"] = True
            return True
        if (
            player.name == "Ignis"
            and not self.puzzle_states["fire_gate"]
            and self._near(player, (1660, 425), 105)
        ):
            self.puzzle_states["fire_lit"] = True
            return True
        return False

    @staticmethod
    def _near(player, position, radius):
        return (player.x - position[0]) ** 2 + (player.y - position[1]) ** 2 <= radius ** 2

    def _puzzle_barriers(self):
        barriers = []
        if not self.puzzle_states["plant_gate"]:
            barriers.append(self._gate_rect(self.PLANT_GATE_X))
        if not self.puzzle_states["water_gate"]:
            barriers.append(self._gate_rect(self.WATER_GATE_X))
        if not self.puzzle_states["fire_gate"]:
            barriers.extend(
                (
                    pygame.Rect(self.FIRE_GATE_X - 19, HUD_HEIGHT, 38, self.PUZZLE_GATE_TOP - HUD_HEIGHT),
                    self._gate_rect(self.FIRE_GATE_X),
                    pygame.Rect(
                        self.FIRE_GATE_X - 19,
                        self.DOOR_CENTER_Y + self.DOOR_HALF_HEIGHT,
                        38,
                        HEIGHT - self.DOOR_CENTER_Y - self.DOOR_HALF_HEIGHT,
                    ),
                )
            )
        return barriers

    def _gate_rect(self, x):
        return pygame.Rect(x - 19, self.PUZZLE_GATE_TOP, 38, self.DOOR_HALF_HEIGHT * 2)

    def update_combat_state(self, players):
        if (
            not self.combat_started
            and len(players) == 3
            and all(self._inside_combat_room(player) for player in players)
        ):
            self.combat_started = True
            self.combat_locked = True
            self.combat_players.update(players)
            enemy_sprites = self.assets.enemy_sprites if self.assets else {}
            self.enemies = [
                Enemy(
                    2300, 330, radius=21, color=(137, 111, 84), health=130,
                    kind="guardian", sprite_frames=enemy_sprites.get("guardian"),
                ),
                Enemy(
                    2500, 535, radius=18, color=(255, 120, 45), health=75,
                    kind="fire", sprite_frames=enemy_sprites.get("fire"),
                ),
                Enemy(
                    2680, 410, radius=20, color=(92, 161, 67), health=95,
                    kind="plant", sprite_frames=enemy_sprites.get("plant"),
                ),
                Enemy(
                    2370, 510, radius=17, color=(137, 111, 84), health=100,
                    kind="guardian", sprite_frames=enemy_sprites.get("guardian"),
                ),
            ]

        if self.combat_locked:
            self.combat_players.update(
                player
                for player in players
                if self.ROOM_WIDTH * self.COMBAT_ROOM_INDEX <= player.x
                < self.ROOM_WIDTH * (self.COMBAT_ROOM_INDEX + 1)
            )

        if self.combat_started and all(enemy.health <= 0 for enemy in self.enemies):
            self.combat_complete = True
            self.combat_locked = False

    def update_exit(self, dt, players):
        if self.level_completed:
            return

        occupants = set()
        for player in players:
            target = self.exit_sigils.get(player.name)
            if (
                target
                and player.health > 0
                and (player.x - target[0]) ** 2 + (player.y - target[1]) ** 2 <= 36 ** 2
            ):
                occupants.add(player.name)

        self.exit_occupants = occupants
        for name, charge in self.exit_sigil_charge.items():
            if name in occupants:
                self.exit_sigil_charge[name] = min(
                    1.0, charge + dt / self.EXIT_LIGHT_SECONDS
                )
            else:
                self.exit_sigil_charge[name] = max(
                    0.0, charge - dt / self.EXIT_LIGHT_SECONDS
                )

        if len(players) == 3 and len(occupants) == 3:
            self.exit_charge += dt
            self.exit_light = min(
                1.0,
                self.exit_light + dt / self.EXIT_LIGHT_SECONDS,
            )
            if self.exit_charge >= self.EXIT_HOLD_SECONDS:
                self.level_completed = True
        else:
            self.exit_charge = 0.0
            self.exit_light = max(0.0, self.exit_light - dt / 0.4)

    def get_wall_rects_for_player(self, player):
        walls = self.walls + self._puzzle_barriers()
        if self.combat_locked and player in self.combat_players:
            walls += self._combat_door_rects()
        return walls

    def _inside_combat_room(self, player):
        left = self.COMBAT_ROOM_INDEX * self.ROOM_WIDTH + 56
        right = left + self.ROOM_WIDTH - 112
        return left <= player.x <= right

    def _combat_door_rects(self):
        top = self.DOOR_CENTER_Y - self.DOOR_HALF_HEIGHT
        height = self.DOOR_HALF_HEIGHT * 2
        return [
            pygame.Rect(
                boundary * self.ROOM_WIDTH,
                top,
                38,
                height,
            )
            for boundary in (self.COMBAT_ROOM_INDEX, self.COMBAT_ROOM_INDEX + 1)
        ]

    def _build_walls(self):
        top = HUD_HEIGHT
        bottom = HEIGHT
        wall_thickness = 38
        walls = [
            pygame.Rect(0, top, self.WORLD_WIDTH, wall_thickness),
            pygame.Rect(0, bottom - wall_thickness, self.WORLD_WIDTH, wall_thickness),
            pygame.Rect(0, top, wall_thickness, bottom - top),
            pygame.Rect(self.WORLD_WIDTH - wall_thickness, top, wall_thickness, bottom - top),
        ]

        for boundary in range(1, self.ROOM_COUNT):
            x = boundary * self.ROOM_WIDTH
            doorway_top = self.DOOR_CENTER_Y - self.DOOR_HALF_HEIGHT
            doorway_bottom = self.DOOR_CENTER_Y + self.DOOR_HALF_HEIGHT
            walls.extend(
                (
                    pygame.Rect(x, top, wall_thickness, doorway_top - top),
                    pygame.Rect(x, doorway_bottom, wall_thickness, bottom - doorway_bottom),
                )
            )

        return walls

    @property
    def wall_rects(self):
        return self.walls

    def draw(self, surface, camera=(0, 0)):
        if self.assets:
            self.assets.draw_floor(surface, camera, self.floor)
        else:
            surface.fill((77, 69, 60))

        camera_x, camera_y = round(camera[0]), round(camera[1])
        for index, wall in enumerate(self.walls):
            screen_wall = wall.move(-camera_x, -camera_y)
            if self.assets:
                self.assets.draw_wall(
                    surface,
                    screen_wall,
                    HUD_HEIGHT,
                    extend=index < self.STRUCTURAL_WALL_COUNT,
                )

        if not self.puzzle_states["fire_gate"]:
            for wall in self._fire_gate_side_walls():
                screen_wall = wall.move(-camera_x, -camera_y)
                if self.assets:
                    self.assets.draw_wall(surface, screen_wall, HUD_HEIGHT, extend=True)

        self._draw_wall_junctions(surface, camera)
        self._draw_decorations(surface, camera)
        self._draw_room_landmarks(surface, camera_x, camera_y, camera)
        self._draw_puzzles(surface, camera)
        for enemy in self.enemies:
            if enemy.health <= 0:
                continue
            enemy.draw(surface, camera)
            bar = pygame.Rect(round(enemy.x - 20 - camera_x), round(enemy.y - enemy.radius - 14 - camera_y), 40, 6)
            pygame.draw.rect(surface, (20, 20, 20), bar)
            pygame.draw.rect(surface, (90, 220, 110), (bar.x, bar.y, round(40 * enemy.health / enemy.max_health), bar.height))
            label = self.detail_font.render(
                {"guardian": "Guardian", "fire": "Fire Creature", "plant": "Plant Monster"}[enemy.kind],
                True,
                (245, 220, 180),
            )
            surface.blit(label, label.get_rect(midbottom=(round(enemy.x - camera_x), bar.y - 2)))

        if self.combat_locked:
            text = self.detail_font.render("Defeat every guardian to unseal both exits", True, (255, 215, 150))
            surface.blit(text, text.get_rect(center=(surface.get_width() // 2, HUD_HEIGHT + 22)))
        elif not self.combat_started and self.puzzle_states["fire_gate"]:
            text = self.detail_font.render("Bring all three players into the Guardian's Chamber", True, (255, 215, 150))
            surface.blit(text, text.get_rect(center=(surface.get_width() // 2, HUD_HEIGHT + 22)))
        self._draw_exit(surface, camera)

    def _draw_wall_junctions(self, surface, camera):
        if not self.assets:
            return

        self.assets.draw_wall_piece(
            surface, "top_left", (0, HUD_HEIGHT), camera, HUD_HEIGHT, anchor="topleft"
        )
        self.assets.draw_wall_piece(
            surface,
            "top_right",
            (self.WORLD_WIDTH, HUD_HEIGHT),
            camera,
            HUD_HEIGHT,
            anchor="topright",
        )
        self.assets.draw_wall_piece(
            surface,
            "bottom_left",
            (0, HEIGHT - 38 - self.BOTTOM_CORNER_CAP_OFFSET),
            camera,
            HUD_HEIGHT,
            anchor="topleft",
        )
        self.assets.draw_wall_piece(
            surface,
            "bottom_right",
            (self.WORLD_WIDTH, HEIGHT - 38 - self.BOTTOM_CORNER_CAP_OFFSET),
            camera,
            HUD_HEIGHT,
            anchor="topright",
        )

    def _draw_puzzles(self, surface, camera):
        camera_x, camera_y = round(camera[0]), round(camera[1])
        self._draw_gate(surface, self.FIRE_GATE_X, camera_x, camera_y, not self.puzzle_states["fire_gate"])

        if not self.puzzle_states["plant_gate"]:
            self._draw_interactive(surface, "plant_vines", (self.PLANT_GATE_X, self.DOOR_CENTER_Y + 18), (78, 112), camera)
        self._draw_interactive(surface, "water_vortex", (1260, 485), (58, 58), camera)
        self._draw_interactive(surface, "water_switch", (self.WATER_GATE_X - 44, self.DOOR_CENTER_Y + 18), (48, 48), camera)
        self._draw_interactive(surface, "ground_flame", (1660, 465), (52, 50), camera)
        self._draw_interactive(surface, "fire_switch", (self.FIRE_GATE_X - 42, self.DOOR_CENTER_Y + 18), (46, 44), camera)
        self._draw_interactive(surface, "stone_pedestal", (1820, 515), (48, 58), camera)
        if self.puzzle_states["water_gate"]:
            pygame.draw.line(
                surface,
                (91, 207, 255),
                (1260 - camera_x, 455 - camera_y),
                (self.WATER_GATE_X - 44 - camera_x, self.DOOR_CENTER_Y - camera_y),
                5,
            )
            pygame.draw.circle(surface, (171, 235, 255), (self.WATER_GATE_X - 44 - camera_x, self.DOOR_CENTER_Y - camera_y), 13, 2)
        if self.puzzle_states["fire_lit"]:
            pygame.draw.circle(surface, (255, 164, 50), (1660 - camera_x, 445 - camera_y), 38, 3)
            pygame.draw.circle(surface, (255, 226, 130), (1660 - camera_x, 445 - camera_y), 25, 2)
            pygame.draw.circle(surface, (255, 208, 112), (1820 - camera_x, 490 - camera_y), 42, 3)
        if self.puzzle_states["fire_gate"]:
            pygame.draw.circle(surface, (255, 194, 80), (self.FIRE_GATE_X - 42 - camera_x, self.DOOR_CENTER_Y - camera_y), 15, 3)

        self._draw_puzzle_label(
            surface,
            "Terra: ability clears vines" if not self.puzzle_states["plant_gate"] else "Vines cleared",
            610,
            345,
            camera_x,
            camera_y,
            self.puzzle_states["plant_gate"],
        )
        self._draw_puzzle_label(
            surface,
            "Aqua: ability redirects water" if not self.puzzle_states["water_gate"] else "Water mechanism active",
            1280,
            345,
            camera_x,
            camera_y,
            self.puzzle_states["water_gate"],
        )
        if not self.puzzle_states["fire_gate"]:
            fire_hint = "Ignis: press O / Ability by flame"
            if self.puzzle_states["fire_lit"]:
                fire_hint = "Flame lit! Aqua: hold H / Interact | Terra: hold P / Interact at altar"
            self._draw_puzzle_label(surface, fire_hint, 1770, 345, camera_x, camera_y, False)
        else:
            self._draw_puzzle_label(surface, "Co-op mechanism unlocked", 1850, 345, camera_x, camera_y, True)

    def _draw_interactive(self, surface, name, center, size, camera):
        if not self.assets or name not in self.assets.interactive:
            return
        image = pygame.transform.scale(self.assets.interactive[name], size)
        rect = image.get_rect(
            midbottom=(round(center[0] - camera[0]), round(center[1] - camera[1]))
        )
        surface.blit(image, rect)

    def _draw_gate(self, surface, x, camera_x, camera_y, closed):
        if not closed:
            return
        if self.assets and "iron_gate" in self.assets.decorations:
            self.assets.draw_decoration(
                surface,
                "iron_gate",
                (x, self.DOOR_CENTER_Y + self.DOOR_HALF_HEIGHT),
                (38, self.DOOR_HALF_HEIGHT * 2),
                (camera_x, camera_y),
            )

    def _fire_gate_side_walls(self):
        x = self.FIRE_GATE_X - 19
        top_height = self.PUZZLE_GATE_TOP - HUD_HEIGHT
        bottom_y = self.DOOR_CENTER_Y + self.DOOR_HALF_HEIGHT
        return (
            pygame.Rect(x, HUD_HEIGHT, 38, top_height),
            pygame.Rect(x, bottom_y, 38, HEIGHT - bottom_y),
        )

    def _draw_puzzle_label(self, surface, text, x, y, camera_x, camera_y, solved):
        color = (173, 235, 155) if solved else (255, 222, 155)
        rendered = self.detail_font.render(text, True, color)
        rect = rendered.get_rect(center=(x - camera_x, y - camera_y))
        backing = rect.inflate(12, 8)
        pygame.draw.rect(surface, (32, 29, 27), backing, border_radius=4)
        surface.blit(rendered, rect)

    def _draw_room_landmarks(self, surface, camera_x, camera_y, camera):
        for index, name in enumerate(self.ROOM_NAMES):
            room_center = index * self.ROOM_WIDTH + self.ROOM_WIDTH // 2
            title = self.room_font.render(name, True, (213, 197, 161))
            title_rect = title.get_rect(center=(room_center - camera_x, 160 - camera_y))
            backing = title_rect.inflate(24, 14)
            pygame.draw.rect(surface, (37, 34, 31), backing, border_radius=5)
            pygame.draw.rect(surface, (112, 94, 68), backing, width=2, border_radius=5)
            surface.blit(title, title_rect)

            if index < self.ROOM_COUNT - 1:
                doorway_x = (index + 1) * self.ROOM_WIDTH
                closed = self.combat_locked and index in (
                    self.COMBAT_ROOM_INDEX - 1,
                    self.COMBAT_ROOM_INDEX,
                )
                puzzle_closed = (
                    (index == 0 and not self.puzzle_states["plant_gate"])
                    or (index == 1 and not self.puzzle_states["water_gate"])
                )
                self._draw_doorway(surface, doorway_x, camera, closed or puzzle_closed)

    def _draw_decorations(self, surface, camera):
        if not self.assets:
            return

        for boundary in range(1, self.ROOM_COUNT):
            self.assets.draw_decoration(
                surface,
                "stone_doorway",
                (boundary * self.ROOM_WIDTH + 19, self.DOOR_CENTER_Y + 48),
                (86, 150),
                camera,
            )

        for x in (480, 880, 1220, 1510, 2020, 2370, 2820, 3220):
            self.assets.draw_decoration(surface, "torch", (x, 178), (34, 72), camera)

        self.assets.draw_decoration(surface, "brazier", (535, 480), (62, 70), camera)
        self.assets.draw_decoration(surface, "brazier", (1760, 490), (62, 70), camera)
        self.assets.draw_decoration(surface, "flowering_plant", (1460, 270), (56, 48), camera)
        self.assets.draw_decoration(surface, "vines", (1680, 214), (112, 62), camera)
        self.assets.draw_decoration(surface, "stone_bench", (1830, 500), (110, 82), camera)
        self.assets.draw_decoration(surface, "bookshelf", (2900, 370), (78, 74), camera)
        self.assets.draw_decoration(surface, "fountain", (3410, 490), (84, 84), camera)

    def _draw_doorway(self, surface, x, camera, closed=False):
        if not closed:
            return

        if self.assets and "iron_gate" in self.assets.decorations:
            self.assets.draw_decoration(
                surface,
                "iron_gate",
                (x, self.DOOR_CENTER_Y + self.DOOR_HALF_HEIGHT),
                (38, self.DOOR_HALF_HEIGHT * 2),
                camera,
            )

    def _draw_exit(self, surface, camera):
        camera_x, camera_y = round(camera[0]), round(camera[1])
        center = (
            self.EXIT_PORTAL_CENTER[0] - camera_x,
            self.EXIT_PORTAL_CENTER[1] - camera_y,
        )
        rect = pygame.Rect(
            center[0] - self.EXIT_PORTAL_SIZE[0] // 2,
            center[1] - self.EXIT_PORTAL_SIZE[1] // 2,
            *self.EXIT_PORTAL_SIZE,
        )
        if self.end_portal_image:
            rect = self.end_portal_image.get_rect(center=center)
            surface.blit(self.end_portal_image, rect)
        else:
            pygame.draw.circle(surface, (70, 65, 85), center, 130)

        sigil_colors = {
            "Aqua": (90, 195, 255),
            "Ignis": (255, 142, 70),
            "Terra": (140, 220, 105),
        }
        self._draw_exit_lighting(surface, rect, sigil_colors)

        for name, position in self.exit_sigils.items():
            point = (round(position[0] - camera_x), round(position[1] - camera_y))
            charge = self.exit_sigil_charge[name]
            color = tuple(
                round(100 + (channel - 100) * charge)
                for channel in sigil_colors[name]
            )
            pygame.draw.circle(surface, color, point, self.EXIT_SIGIL_MARKER_RADIUS, 3)
            if charge > 0:
                pygame.draw.circle(surface, color, point, self.EXIT_SIGIL_MARKER_RADIUS + 5, 1)

        instruction = (
            "All three sigils aligned!" if self.level_completed
            else "Stand on your own emblem together"
        )
        text = self.detail_font.render(instruction, True, (240, 225, 180))
        surface.blit(text, text.get_rect(center=(center[0], center[1] + self.EXIT_PORTAL_SIZE[1] // 2 + 19)))
        bar = pygame.Rect(center[0] - 72, center[1] + self.EXIT_PORTAL_SIZE[1] // 2 + 31, 144, 7)
        pygame.draw.rect(surface, (38, 34, 31), bar, border_radius=3)
        if self.exit_charge > 0:
            fill = round(bar.width * min(1.0, self.exit_charge / self.EXIT_HOLD_SECONDS))
            pygame.draw.rect(surface, (220, 195, 112), (bar.x, bar.y, fill, bar.height), border_radius=3)

    def _draw_exit_lighting(self, surface, portal_rect, sigil_colors):
        charges = self.exit_sigil_charge
        if self.exit_light <= 0 and not any(charges.values()):
            return

        light = pygame.Surface(self.EXIT_PORTAL_SIZE)
        light.fill((0, 0, 0))
        width, height = self.EXIT_PORTAL_SIZE
        center = (width // 2, height // 2)
        portal_left = self.EXIT_PORTAL_CENTER[0] - width // 2
        points = {
            name: (
                round(position[0] - portal_left),
                round(position[1] - (self.EXIT_PORTAL_CENTER[1] - height // 2)),
            )
            for name, position in self.exit_sigils.items()
        }

        if self.exit_light > 0:
            wash = tuple(round(channel * 0.16 * self.exit_light) for channel in (255, 190, 75))
            pygame.draw.circle(light, wash, center, 120)

        for name, point in points.items():
            charge = charges[name]
            if charge <= 0:
                continue
            color = sigil_colors[name]
            for radius, strength in ((56, 0.08), (46, 0.15), (36, 0.24), (29, 0.34)):
                glow = tuple(round(channel * strength * charge) for channel in color)
                pygame.draw.circle(light, glow, point, radius)

        if self.exit_light > 0:
            progress = self.exit_light
            gold = tuple(round(channel * 0.66 * progress) for channel in (255, 190, 75))
            triangle = tuple(points[name] for name in ("Ignis", "Aqua", "Terra"))
            for start, end in zip(triangle, triangle[1:] + triangle[:1]):
                pygame.draw.line(light, gold, start, end, 5)

            rim_gold = tuple(round(channel * 0.36 * progress) for channel in (255, 190, 75))
            pygame.draw.circle(light, rim_gold, center, 123, 5)

        surface.blit(light, portal_rect, special_flags=pygame.BLEND_RGB_ADD)
