"""Controller discovery, assignment, and input processing for three local gamepads."""

from __future__ import annotations

import pygame

from game.settings import MOVEMENT_DEADZONE


class ControllerManager:
    def __init__(self):
        pygame.joystick.init()
        self.joysticks = {}
        self.previous_buttons = {}
        self.current_buttons = {}
        self.confirm_was_down = {}
        self.browser_confirm_was_down = False
        self.browser_confirm_pending = False
        self.browser_move_y = 0.0
        self.browser_move_x = 0.0
        self.browser_attack = False
        self.browser_attack_pressed = False
        self.browser_ability = False
        self.browser_ability_pressed = False
        self.browser_interact = False
        self.browser_interact_pressed = False
        self.browser_switch_pressed = False
        self.browser_switch_was_down = False
        self.browser_gamepads = 0
        self.refresh()

    def refresh(self):
        connected = pygame.joystick.get_count()
        for index in range(connected):
            if index not in self.joysticks:
                joystick = pygame.joystick.Joystick(index)
                joystick.init()
                self.joysticks[index] = joystick
                self.previous_buttons[index] = [False] * max(10, joystick.get_numbuttons())
                self.current_buttons[index] = [False] * max(10, joystick.get_numbuttons())
                self.confirm_was_down[index] = False

        for index in list(self.joysticks):
            if index >= connected:
                del self.joysticks[index]
                self.previous_buttons.pop(index, None)
                self.current_buttons.pop(index, None)
                self.confirm_was_down.pop(index, None)

    def update(self):
        self.refresh()
        for index, joystick in self.joysticks.items():
            current = [bool(joystick.get_button(button_index)) for button_index in range(joystick.get_numbuttons())]
            self.previous_buttons[index] = self.current_buttons.get(index, [False] * len(current))
            self.current_buttons[index] = current
        self._update_browser_gamepads()

    def _update_browser_gamepads(self):
        self.browser_gamepads = 0
        self.browser_move_y = 0.0
        self.browser_move_x = 0.0
        self.browser_attack = False
        self.browser_attack_pressed = False
        self.browser_ability = False
        self.browser_ability_pressed = False
        self.browser_interact = False
        self.browser_interact_pressed = False
        self.browser_switch_pressed = False
        try:
            import sys
            if sys.platform != "emscripten":
                return
            import platform
            navigator = getattr(platform, "navigator", None)
            if navigator is None:
                navigator = platform.window.navigator
            pads = navigator.getGamepads()
            for index in range(4):
                try:
                    pad = pads[index]
                except Exception:
                    pad = None
                if pad is None:
                    continue
                self.browser_gamepads += 1
                buttons = pad.buttons
                confirm_down = bool(buttons[0].pressed) if len(buttons) > 0 else False
                if confirm_down and not self.browser_confirm_was_down:
                    self.browser_confirm_was_down = True
                    self.browser_confirm_pending = True
                elif not confirm_down:
                    self.browser_confirm_was_down = False
                attack_down = bool(buttons[0].pressed) if len(buttons) > 0 else False
                self.browser_attack = attack_down
                self.browser_attack_pressed = attack_down and not getattr(self, "_browser_attack_was_down", False)
                self._browser_attack_was_down = attack_down
                ability_down = bool(buttons[2].pressed) if len(buttons) > 2 else False
                self.browser_ability = ability_down
                self.browser_ability_pressed = ability_down and not getattr(self, "_browser_ability_was_down", False)
                self._browser_ability_was_down = ability_down
                interact_down = bool(buttons[3].pressed) if len(buttons) > 3 else False
                self.browser_interact = interact_down
                self.browser_interact_pressed = interact_down and not getattr(self, "_browser_interact_was_down", False)
                self._browser_interact_was_down = interact_down
                switch_down = bool(buttons[4].pressed) if len(buttons) > 4 else False
                self.browser_switch_pressed = switch_down and not self.browser_switch_was_down
                self.browser_switch_was_down = switch_down
                if len(buttons) > 13:
                    if buttons[12].pressed:
                        self.browser_move_y = -1.0
                    elif buttons[13].pressed:
                        self.browser_move_y = 1.0
                try:
                    axes = pad.axes
                    if abs(float(axes[0])) >= MOVEMENT_DEADZONE:
                        self.browser_move_x = float(axes[0])
                    if abs(float(axes[1])) >= MOVEMENT_DEADZONE:
                        self.browser_move_y = float(axes[1])
                except Exception:
                    try:
                        import platform
                        import json
                        result = platform.window.eval(
                            "JSON.stringify(Array.from(navigator.getGamepads()).filter(function(p){return p!==null}).map(function(p){return {axes:Array.from(p.axes),buttons:p.buttons.map(function(b){return b.pressed})}}))"
                        )
                        snapshots = json.loads(str(result))
                        for snapshot in snapshots:
                            self.browser_gamepads += 1
                            buttons = snapshot.get("buttons", [])
                            axes = snapshot.get("axes", [])
                            confirm_down = bool(buttons[0]) if len(buttons) > 0 else False
                            if confirm_down and not self.browser_confirm_was_down:
                                self.browser_confirm_was_down = True
                                self.browser_confirm_pending = True
                            elif not confirm_down:
                                self.browser_confirm_was_down = False
                            self.browser_attack = confirm_down
                            self.browser_attack_pressed = confirm_down and not getattr(self, "_browser_attack_was_down", False)
                            self._browser_attack_was_down = confirm_down
                            self.browser_ability = bool(buttons[2]) if len(buttons) > 2 else False
                            self.browser_interact = bool(buttons[3]) if len(buttons) > 3 else False
                            if len(axes) > 1:
                                self.browser_move_x = float(axes[0]) if abs(float(axes[0])) >= MOVEMENT_DEADZONE else 0.0
                                self.browser_move_y = float(axes[1]) if abs(float(axes[1])) >= MOVEMENT_DEADZONE else 0.0
                    except Exception:
                        pass
        except Exception:
            pass

    def connected_count(self):
        return max(len(self.joysticks), self.browser_gamepads)

    def get_missing_count(self):
        return max(0, 3 - self.connected_count())

    def menu_confirm_pressed(self):
        if self.browser_confirm_pending:
            self.browser_confirm_pending = False
            return True
        for index, joystick in self.joysticks.items():
            current = self.current_buttons.get(index, [False] * max(10, joystick.get_numbuttons()))
            live = [
                bool(joystick.get_button(button_index))
                for button_index in range(joystick.get_numbuttons())
            ]
            if len(live) > len(current):
                current = live
                self.current_buttons[index] = live
            confirm_down = any(bool(live[button_index]) for button_index in (0, 1, 2, 3) if button_index < len(live))
            if confirm_down and not self.confirm_was_down.get(index, False):
                self.confirm_was_down[index] = True
                return True
            if not confirm_down:
                self.confirm_was_down[index] = False
        return False

    def axis_value(self, joystick, index):
        value = joystick.get_axis(index)
        if abs(value) < MOVEMENT_DEADZONE:
            return 0.0
        return value

    def get_input(self, player_index):
        if player_index not in self.joysticks:
            if self.browser_gamepads > 0:
                return {
                    "move_x": self.browser_move_x,
                    "move_y": self.browser_move_y,
                    "attack": self.browser_attack,
                    "attack_pressed": self.browser_attack_pressed,
                    "ability": self.browser_ability,
                    "ability_pressed": self.browser_ability_pressed,
                    "interact": self.browser_interact,
                    "interact_pressed": self.browser_interact_pressed,
                    "aim_x": 0.0,
                    "aim_y": 0.0,
                    "lt": False,
                    "switch_character_pressed": self.browser_switch_pressed,
                    "pause": False,
                }
            return {
                "move_x": 0.0,
                "move_y": 0.0,
                "attack": False,
                "attack_pressed": False,
                "ability": False,
                "ability_pressed": False,
                "interact": False,
                "interact_pressed": False,
                "aim_x": 0.0,
                "aim_y": 0.0,
                "lt": False,
                "switch_character_pressed": False,
                "pause": False,
            }

        joystick = self.joysticks[player_index]
        current = self.current_buttons.get(player_index, [False] * max(10, joystick.get_numbuttons()))
        previous = self.previous_buttons.get(player_index, [False] * len(current))

        def pressed(button_index):
            return bool(current[button_index]) and not previous[button_index] if button_index < len(previous) and button_index < len(current) else False

        move_x = self.axis_value(joystick, 0)
        move_y = self.axis_value(joystick, 1)
        aim_x = self.axis_value(joystick, 2) if joystick.get_numaxes() > 2 else 0.0
        aim_y = self.axis_value(joystick, 3) if joystick.get_numaxes() > 3 else 0.0
        lt_axis = joystick.get_axis(4) if joystick.get_numaxes() > 4 else -1.0

        return {
            "move_x": move_x,
            "move_y": move_y,
            "attack": bool(current[0]) if len(current) > 0 else False,
            "attack_pressed": pressed(0),
            "ability": bool(current[2]) if len(current) > 2 else False,
            "ability_pressed": pressed(2),
            "interact": bool(current[3]) if len(current) > 3 else False,
            "interact_pressed": pressed(3),
            "aim_x": aim_x,
            "aim_y": aim_y,
            "lt": lt_axis > 0.5 or bool(current[4]) if len(current) > 4 else lt_axis > 0.5,
            "switch_character_pressed": pressed(5),
            "pause": any(current[index] for index in (7, 9) if index < len(current)),
        }
