"""Loading and preparing the supplied sprite sheet artwork."""

from __future__ import annotations

from pathlib import Path
import random

import pygame

from game.settings import HEIGHT, WIDTH


class GameAssets:
    WALL_BLOCK_SIZE = 38
    WALL_BLOCK_OVERLAP = 1
    VERTICAL_WALL_BLOCK_OVERLAP = 9

    def __init__(self):
        game_root = Path(__file__).resolve().parents[1]
        icon_path = game_root / "assets" / "favicon.png"
        self.game_icon = pygame.image.load(str(icon_path)).convert_alpha()
        self.title_logo = pygame.image.load(
            str(game_root / "assets" / "Mossy ivy Trinity logo.png")
        ).convert_alpha()
        self.player_sprites = {
            "Terra": self._load_directional_sprites(game_root / "assets" / "characters" / "terra.png"),
            "Aqua": self._load_directional_sprites(game_root / "assets" / "characters" / "aqua.png"),
            "Ignis": self._load_directional_sprites(game_root / "assets" / "characters" / "ignis.png"),
        }
        self.dead_sprites = {
            "Terra": pygame.image.load(str(game_root / "assets" / "characters" / "terra_dead.png")).convert_alpha(),
            "Aqua": pygame.image.load(str(game_root / "assets" / "characters" / "aqua_dead.png")).convert_alpha(),
            "Ignis": pygame.image.load(str(game_root / "assets" / "characters" / "ignis_dead.png")).convert_alpha(),
        }
        self.ignis_fireball = pygame.image.load(
            str(game_root / "assets" / "attacks" / "ignis_fireball.png")
        ).convert_alpha()
        self.ice_projectile = pygame.image.load(
            str(game_root / "assets" / "attacks" / "ice projectile.png")
        ).convert_alpha()
        self.fire_whip = pygame.image.load(
            str(game_root / "assets" / "attacks" / "fire whip.png")
        ).convert_alpha()
        self.scratch = pygame.image.load(
            str(game_root / "assets" / "attacks" / "scratch.png")
        ).convert_alpha()
        enemy_dir = game_root / "assets" / "enemies"
        self.enemy_sprites = {
            "plant": self._load_enemy_frames(enemy_dir / "plant_slime.png"),
            "fire": self._load_enemy_frames(enemy_dir / "fire_slime.png"),
            "guardian": self._load_enemy_frames(enemy_dir / "guardian_slime.png"),
        }
        self.end_portal = pygame.image.load(str(game_root / "assets" / "end_portal.png")).convert_alpha()
        interactive_dir = game_root / "assets" / "interactive"
        self.interactive = {
            name: pygame.image.load(str(interactive_dir / f"{name}.png")).convert_alpha()
            for name in (
                "greenbarrier",
                "water_vortex",
                "water source",
                "water_switch",
                "bubble",
                "ground_flame",
            )
        }
        fireplace_source = pygame.image.load(
            str(interactive_dir / "fireplace.png")
        ).convert_alpha()
        fireplace_width = fireplace_source.get_width() // 2
        fireplace_halves = []
        for index in range(2):
            half = fireplace_source.subsurface(
                pygame.Rect(index * fireplace_width, 0, fireplace_width, fireplace_source.get_height())
            ).copy()
            fireplace_halves.append(half)
        visible_halves = [
            half.subsurface(half.get_bounding_rect(min_alpha=8)).copy()
            for half in fireplace_halves
        ]
        canvas_width = max(image.get_width() for image in visible_halves)
        canvas_height = max(image.get_height() for image in visible_halves)
        fireplace_states = []
        for image in visible_halves:
            aligned = pygame.Surface(
                (canvas_width, canvas_height),
                pygame.SRCALPHA,
            )
            aligned.blit(
                image,
                (
                    (canvas_width - image.get_width()) // 2,
                    canvas_height - image.get_height(),
                ),
            )
            fireplace_states.append(aligned)
        self.fireplace_lit, self.fireplace_unlit = fireplace_states
        decoration_dir = game_root / "assets" / "decorations"
        decoration_names = (
            "wooden_door",
            "torch",
            "brazier",
            "vines",
            "flowering_plant",
            "fountain",
            "stone_bench",
            "bookshelf",
        )
        self.decorations = {
            name: pygame.image.load(str(path)).convert_alpha()
            for name in decoration_names
            for path in (decoration_dir / f"{name}.png",)
            if path.is_file()
        }
        wall_dir = game_root / "assets" / "walls"
        block_sources = tuple(
            pygame.image.load(str(wall_dir / filename)).convert_alpha()
            for filename in (
                "wall block1.png",
                "wall block2.png",
                "wall block3.png",
                "wall block4.png",
                "wall block5.png",
                "wall block6.png",
                "wall block7.png",
                "wall block8.png",
                "wall block9.png",
                "wall block10.png",
            )
        )
        stripe_source = pygame.image.load(str(wall_dir / "wall stripe.png")).convert_alpha()
        block_scale = self.WALL_BLOCK_SIZE / block_sources[0].get_width()
        blocks = tuple(
            pygame.transform.scale(
                source,
                (
                    self.WALL_BLOCK_SIZE,
                    round(source.get_height() * block_scale),
                ),
            )
            for source in block_sources
        )
        self.wall_block_height = blocks[0].get_height()
        stripe_height = round(stripe_source.get_height() * block_scale)
        horizontal_stripe = pygame.transform.scale(
            stripe_source, (self.WALL_BLOCK_SIZE, stripe_height)
        )
        self.horizontal_wall_tiles = []
        for block in blocks:
            wall_tile = pygame.Surface(
                (
                    self.WALL_BLOCK_SIZE,
                    block.get_height() + horizontal_stripe.get_height(),
                ),
                pygame.SRCALPHA,
            )
            wall_tile.blit(block, (0, 0))
            wall_tile.blit(horizontal_stripe, (0, block.get_height()))
            self.horizontal_wall_tiles.append(wall_tile)
        self.horizontal_wall_tiles = tuple(self.horizontal_wall_tiles)
        self.vertical_wall_tiles = self.horizontal_wall_tiles
        self.horizontal_wall_tile = self.horizontal_wall_tiles[0]
        self.floor = self._create_floor(WIDTH, HEIGHT)

    @staticmethod
    def _load_directional_sprites(path):
        sheet = pygame.image.load(str(path)).convert_alpha()
        frame_width = sheet.get_width() // 4
        if frame_width * 4 != sheet.get_width():
            raise ValueError(f"Character sprite sheet must contain four equal frames: {path}")
        directions = ("down", "up", "right", "left")
        return {
            direction: sheet.subsurface(
                pygame.Rect(index * frame_width, 0, frame_width, sheet.get_height())
            ).copy()
            for index, direction in enumerate(directions)
        }

    @staticmethod
    def _load_enemy_frames(path):
        sheet = pygame.image.load(str(path)).convert_alpha()
        frame_width = sheet.get_width() // 6
        if frame_width * 6 != sheet.get_width():
            raise ValueError(f"Enemy sprite sheet must contain six equal frames: {path}")
        frames = []
        for index in range(6):
            frame = sheet.subsurface(
                pygame.Rect(index * frame_width, 0, frame_width, sheet.get_height())
            ).copy()
            visible_bounds = frame.get_bounding_rect(min_alpha=8)
            if visible_bounds.width == 0 or visible_bounds.height == 0:
                raise ValueError(f"Enemy sprite frame {index} is empty: {path}")
            frames.append(frame.subsurface(visible_bounds).copy())
        return tuple(frames)

    def create_floor(self, width, height):
        return self._create_floor(width, height)

    @staticmethod
    def _create_floor(width, height):
        scale = 2
        floor = pygame.Surface((width // scale, height // scale))
        floor.fill((25, 23, 22))
        rng = random.Random(418)
        row_y = -24
        row_index = 0

        while row_y < floor.get_height() + 24:
            row_height = rng.randint(9, 13)
            x = rng.randint(-28, -10) if row_index % 2 == 0 else rng.randint(-22, -8)
            while x < floor.get_width() + 28:
                stone_width = rng.randint(10, 18)
                left = x + rng.randint(1, 2)
                top = row_y + rng.randint(1, 2)
                right = x + stone_width - rng.randint(1, 2)
                bottom = row_y + row_height - rng.randint(1, 2)
                points = [
                    (left + 2, top),
                    (right - 2, top),
                    (right, top + 2),
                    (right, bottom - 2),
                    (right - 2, bottom),
                    (left + 2, bottom),
                    (left, bottom - 2),
                    (left, top + 2),
                ]
                shade = rng.randint(-6, 7)
                stone = (
                    max(0, min(255, 57 + shade)),
                    max(0, min(255, 51 + shade)),
                    max(0, min(255, 45 + shade)),
                )
                pygame.draw.rect(floor, stone, (x, row_y, stone_width, row_height))
                pygame.draw.polygon(floor, stone, points)
                pygame.draw.lines(floor, (86, 75, 63), True, points, 1)

                if rng.random() < 0.26:
                    moss_x = rng.randint(left + 4, max(left + 4, right - 5))
                    moss_y = rng.randint(top + 3, max(top + 3, bottom - 4))
                    pygame.draw.ellipse(
                        floor,
                        rng.choice(((48, 47, 37), (58, 53, 39), (42, 42, 34))),
                        (moss_x, moss_y, rng.randint(2, 6), rng.randint(1, 3)),
                    )

                if rng.random() < 0.18:
                    crack_x = rng.randint(left + 5, max(left + 5, right - 5))
                    crack_y = rng.randint(top + 4, max(top + 4, bottom - 3))
                    pygame.draw.line(floor, (12, 11, 11), (crack_x, crack_y), (crack_x + 2, crack_y + 2), 1)

                if rng.random() < 0.3:
                    speck_x = rng.randint(left + 3, max(left + 3, right - 3))
                    speck_y = rng.randint(top + 3, max(top + 3, bottom - 3))
                    pygame.draw.rect(floor, (97, 84, 69), (speck_x, speck_y, 1, 1))

                x += stone_width - 1

            row_y += row_height - 1
            row_index += 1

        return pygame.transform.scale(floor, (width, height))

    def draw_floor(self, surface, camera=(0, 0), floor=None):
        surface.blit(floor or self.floor, (-round(camera[0]), -round(camera[1])))

    def draw_wall(
        self,
        surface,
        rect,
        hud_height,
        camera=(0, 0),
        bottom_aligned=False,
        skip_top_block=True,
    ):
        horizontal = rect.width >= rect.height
        world_left = rect.left + round(camera[0])
        world_top = rect.top + round(camera[1])
        rng = random.Random(world_left * 73856093 ^ world_top * 19349663)
        screen_rect = pygame.Rect(
            0, hud_height, surface.get_width(), surface.get_height() - hud_height
        )
        if horizontal:
            tiles = self.horizontal_wall_tiles
            tile = tiles[0]
            tile_y = rect.top
            visual_rect = pygame.Rect(rect.left, tile_y, rect.width, tile.get_height())
        else:
            tiles = self.vertical_wall_tiles
            tile = tiles[0]
            horizontal_step = (
                self.horizontal_wall_tiles[0].get_width() - self.WALL_BLOCK_OVERLAP
            )
            aligned_world_left = round(world_left / horizontal_step) * horizontal_step
            tile_x = aligned_world_left - round(camera[0])
            visual_rect = pygame.Rect(tile_x, rect.top, tile.get_width(), rect.height)

        old_clip = surface.get_clip()
        clip_rect = old_clip.clip(screen_rect).clip(visual_rect)
        if not clip_rect:
            return

        surface.set_clip(clip_rect)
        try:
            if horizontal:
                step = tile.get_width() - self.WALL_BLOCK_OVERLAP
                for x in range(rect.left, rect.right, step):
                    tile = rng.choice(tiles)
                    surface.blit(tile, (x, tile_y))
            else:
                step = self.wall_block_height - self.VERTICAL_WALL_BLOCK_OVERLAP
                start_y = (
                    rect.top + step
                    if rect.top == hud_height and skip_top_block
                    else rect.top
                )
                last_block_bottom = None
                ends_at_bottom = bottom_aligned or world_top + rect.height >= HEIGHT
                for y in range(start_y, rect.bottom, step):
                    required_height = (
                        self.wall_block_height if ends_at_bottom else tile.get_height()
                    )
                    if y + required_height > rect.bottom:
                        break
                    tile = rng.choice(tiles)
                    surface.blit(tile, (tile_x, y))
                    last_block_bottom = y + self.wall_block_height
                if ends_at_bottom:
                    tile = rng.choice(tiles)
                    surface.blit(
                        tile,
                        (tile_x, rect.bottom - self.wall_block_height),
                    )
                elif last_block_bottom is not None and last_block_bottom < rect.bottom:
                    stripe = tile.subsurface(
                        (0, self.wall_block_height, tile.get_width(), tile.get_height() - self.wall_block_height)
                    )
                    surface.blit(stripe, (tile_x, last_block_bottom))
        finally:
            surface.set_clip(old_clip)

    def draw_decoration(self, surface, name, center, size, camera=(0, 0)):
        image = self.decorations.get(name)
        if image is None:
            return
        scaled = pygame.transform.scale(image, size)
        rect = scaled.get_rect(
            midbottom=(round(center[0] - camera[0]), round(center[1] - camera[1]))
        )
        surface.blit(scaled, rect)
