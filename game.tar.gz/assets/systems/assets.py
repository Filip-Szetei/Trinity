"""Loading and preparing the supplied sprite sheet artwork."""

from __future__ import annotations

from pathlib import Path
import random

import pygame

from game.settings import HEIGHT, WIDTH


class GameAssets:
    VERTICAL_WALL_TILE_OVERLAP = 8
    WALL_ASSET_FILES = {
        "horizontal": "horizontal wall.png",
        "vertical": "vertical wall.png",
        "top_right": "top-right corner.png",
        "bottom_right": "bottom right corner.png",
    }

    def __init__(self):
        game_root = Path(__file__).resolve().parents[1]
        icon_path = game_root / "assets" / "favicon.png"
        self.game_icon = pygame.image.load(str(icon_path)).convert_alpha()
        self.player_sprites = {
            "Terra": self._load_directional_sprites(game_root / "assets" / "characters" / "terra.png"),
            "Aqua": self._load_directional_sprites(game_root / "assets" / "characters" / "aqua.png"),
            "Ignis": self._load_directional_sprites(game_root / "assets" / "characters" / "ignis.png"),
        }
        self.dead_sprites = {
            "Terra": pygame.image.load(str(game_root / "assets" / "characters" / "terra_dead.png")).convert_alpha(),
            "Aqua": pygame.image.load(str(game_root / "assets" / "characters" / "aqua_dead.png")).convert_alpha(),
            "Ignis": pygame.image.load(str(game_root / "assets" / "characters" / "ignis_dead.png")).convert_alpha(),
        }
        self.ignis_fireball = pygame.image.load(
            str(game_root / "assets" / "attacks" / "ignis_fireball.png")
        ).convert_alpha()
        enemy_dir = game_root / "assets" / "enemies"
        self.enemy_sprites = {
            "plant": self._load_enemy_frames(enemy_dir / "plant_slime.png"),
            "fire": self._load_enemy_frames(enemy_dir / "fire_slime.png"),
            "guardian": self._load_enemy_frames(enemy_dir / "guardian_slime.png"),
        }
        self.end_portal = pygame.image.load(str(game_root / "assets" / "end_portal.png")).convert_alpha()
        interactive_dir = game_root / "assets" / "interactive"
        self.interactive = {
            name: pygame.image.load(str(interactive_dir / f"{name}.png")).convert_alpha()
            for name in (
                "plant_vines",
                "water_vortex",
                "water_switch",
                "ground_flame",
                "fire_switch",
                "stone_pedestal",
            )
        }
        decoration_dir = game_root / "assets" / "decorations"
        decoration_names = (
            "stone_doorway",
            "wooden_door",
            "iron_gate",
            "torch",
            "brazier",
            "vines",
            "flowering_plant",
            "fountain",
            "stone_bench",
            "bookshelf",
        )
        self.decorations = {
            name: pygame.image.load(str(path)).convert_alpha()
            for name in decoration_names
            for path in (decoration_dir / f"{name}.png",)
            if path.is_file()
        }
        wall_dir = game_root / "assets" / "walls"
        source_wall_images = {
            name: pygame.image.load(str(wall_dir / filename)).convert_alpha()
            for name, filename in self.WALL_ASSET_FILES.items()
        }
        wall_scale = 38 / source_wall_images["vertical"].get_width()
        self.wall_images = {
            name: pygame.transform.scale(
                image,
                (
                    round(image.get_width() * wall_scale),
                    round(image.get_height() * wall_scale),
                ),
            )
            for name, image in source_wall_images.items()
        }
        self.wall_images["top_left"] = pygame.transform.flip(
            self.wall_images["top_right"], True, False
        )
        self.wall_images["bottom_left"] = pygame.transform.flip(
            self.wall_images["bottom_right"], True, False
        )
        self.floor = self._create_floor(WIDTH, HEIGHT)

    @staticmethod
    def _load_directional_sprites(path):
        sheet = pygame.image.load(str(path)).convert_alpha()
        frame_width = sheet.get_width() // 4
        if frame_width * 4 != sheet.get_width():
            raise ValueError(f"Character sprite sheet must contain four equal frames: {path}")
        directions = ("down", "up", "right", "left")
        return {
            direction: sheet.subsurface(
                pygame.Rect(index * frame_width, 0, frame_width, sheet.get_height())
            ).copy()
            for index, direction in enumerate(directions)
        }

    @staticmethod
    def _load_enemy_frames(path):
        sheet = pygame.image.load(str(path)).convert_alpha()
        frame_width = sheet.get_width() // 6
        if frame_width * 6 != sheet.get_width():
            raise ValueError(f"Enemy sprite sheet must contain six equal frames: {path}")
        frames = []
        for index in range(6):
            frame = sheet.subsurface(
                pygame.Rect(index * frame_width, 0, frame_width, sheet.get_height())
            ).copy()
            visible_bounds = frame.get_bounding_rect(min_alpha=8)
            if visible_bounds.width == 0 or visible_bounds.height == 0:
                raise ValueError(f"Enemy sprite frame {index} is empty: {path}")
            frames.append(frame.subsurface(visible_bounds).copy())
        return tuple(frames)

    def create_floor(self, width, height):
        return self._create_floor(width, height)

    @staticmethod
    def _create_floor(width, height):
        scale = 2
        floor = pygame.Surface((width // scale, height // scale))
        floor.fill((77, 69, 60))
        rng = random.Random(418)
        row_y = -24
        row_index = 0

        while row_y < floor.get_height() + 24:
            row_height = rng.randint(17, 24)
            x = rng.randint(-28, 8) if row_index % 2 == 0 else rng.randint(-14, 22)
            while x < floor.get_width() + 28:
                stone_width = rng.randint(22, 38)
                left = x + rng.randint(1, 3)
                top = row_y + rng.randint(1, 3)
                right = x + stone_width - rng.randint(1, 3)
                bottom = row_y + row_height - rng.randint(1, 3)
                points = [
                    (left + rng.randint(2, 6), top),
                    (right - rng.randint(2, 7), top + rng.randint(0, 2)),
                    (right, top + rng.randint(3, 7)),
                    (right - rng.randint(0, 4), bottom - rng.randint(1, 4)),
                    (left + rng.randint(3, 8), bottom),
                    (left, bottom - rng.randint(3, 7)),
                ]
                shade = rng.randint(-9, 10)
                stone = (
                    max(0, min(255, 119 + shade)),
                    max(0, min(255, 108 + shade)),
                    max(0, min(255, 94 + shade)),
                )
                pygame.draw.polygon(floor, stone, points)
                pygame.draw.lines(floor, (143, 130, 111), False, points[:3], 1)

                if rng.random() < 0.26:
                    moss_x = rng.randint(left + 4, max(left + 4, right - 5))
                    moss_y = rng.randint(top + 3, max(top + 3, bottom - 4))
                    pygame.draw.ellipse(
                        floor,
                        rng.choice(((74, 91, 56), (83, 99, 60), (68, 84, 53))),
                        (moss_x, moss_y, rng.randint(2, 6), rng.randint(1, 3)),
                    )

                if rng.random() < 0.18:
                    crack_x = rng.randint(left + 5, max(left + 5, right - 5))
                    crack_y = rng.randint(top + 4, max(top + 4, bottom - 3))
                    pygame.draw.line(floor, (79, 73, 65), (crack_x, crack_y), (crack_x + 2, crack_y + 2), 1)

                if rng.random() < 0.3:
                    speck_x = rng.randint(left + 3, max(left + 3, right - 3))
                    speck_y = rng.randint(top + 3, max(top + 3, bottom - 3))
                    pygame.draw.rect(floor, (155, 141, 121), (speck_x, speck_y, 1, 1))

                x += stone_width

            row_y += row_height
            row_index += 1

        return pygame.transform.scale(floor, (width, height))

    def draw_floor(self, surface, camera=(0, 0), floor=None):
        surface.blit(floor or self.floor, (-round(camera[0]), -round(camera[1])))

    def draw_wall(self, surface, rect, hud_height, extend=False):
        old_clip = surface.get_clip()
        visible_rect = rect.clip(pygame.Rect(0, hud_height, surface.get_width(), surface.get_height() - hud_height))
        horizontal = rect.width >= rect.height
        clip_rect = visible_rect
        if horizontal and extend:
            clip_rect = pygame.Rect(
                0, hud_height, surface.get_width(), surface.get_height() - hud_height
            )
        if not clip_rect:
            return

        surface.set_clip(old_clip.clip(clip_rect))
        try:
            if horizontal:
                tile = self.wall_images["horizontal"]
                for x in range(rect.left, rect.right, tile.get_width()):
                    surface.blit(tile, (x, rect.top))
            else:
                tile = self.wall_images["vertical"]
                x = rect.centerx - tile.get_width() // 2
                step = tile.get_height() - self.VERTICAL_WALL_TILE_OVERLAP
                for y in range(rect.top, rect.bottom, step):
                    surface.blit(tile, (x, y))
        finally:
            surface.set_clip(old_clip)

    def draw_wall_piece(self, surface, name, world_position, camera, hud_height, anchor="topleft"):
        image = self.wall_images[name]
        position = (
            round(world_position[0] - camera[0]),
            round(world_position[1] - camera[1]),
        )
        rect = image.get_rect(**{anchor: position})
        old_clip = surface.get_clip()
        visible_area = pygame.Rect(
            0, hud_height, surface.get_width(), surface.get_height() - hud_height
        )
        surface.set_clip(old_clip.clip(visible_area))
        try:
            surface.blit(image, rect)
        finally:
            surface.set_clip(old_clip)

    def draw_decoration(self, surface, name, center, size, camera=(0, 0)):
        image = self.decorations.get(name)
        if image is None:
            return
        scaled = pygame.transform.scale(image, size)
        rect = scaled.get_rect(
            midbottom=(round(center[0] - camera[0]), round(center[1] - camera[1]))
        )
        surface.blit(scaled, rect)
