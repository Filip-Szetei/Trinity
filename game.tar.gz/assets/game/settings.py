"""Global game configuration for the co-op prototype."""

WIDTH = 1280
HEIGHT = 796
FPS = 60
HUD_HEIGHT = 90

PLAYER_COLORS = {
    "Aqua": (78, 170, 255),
    "Ignis": (255, 120, 60),
    "Terra": (90, 190, 110),
}

PLAYER_STARTS = {
    "Aqua": (220, 210),
    "Ignis": (320, 300),
    "Terra": (260, 420),
}

PLAYER_ORDER = ["Aqua", "Ignis", "Terra"]
MAX_HEALTH = 100
MOVEMENT_DEADZONE = 0.15
JOYSTICK_COUNT_REQUIRED = 3
