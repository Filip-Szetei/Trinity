"""Minimal menu and overlay helpers."""

from __future__ import annotations

import pygame

from game.settings import HEIGHT, WIDTH


class MenuOverlay:
    def __init__(self, assets=None):
        self.assets = assets
        self.title_font = pygame.font.SysFont(None, 78, bold=True)
        self.option_font = pygame.font.SysFont(None, 38)
        self.small_font = pygame.font.SysFont(None, 24)
        self.control_heading_font = pygame.font.SysFont(None, 34, bold=True)
        self.control_label_font = pygame.font.SysFont(None, 22)
        self.control_value_font = pygame.font.SysFont(None, 23, bold=True)
        self.control_hint_font = pygame.font.SysFont(None, 20)

    def draw_main_menu(self, surface, selected, connected_controllers):
        logical_surface = pygame.Surface((WIDTH, HEIGHT))
        self._draw_main_menu(
            logical_surface,
            selected,
            connected_controllers,
        )
        scaled = pygame.transform.smoothscale(logical_surface, surface.get_size())
        surface.blit(scaled, (0, 0))

    def _draw_main_menu(self, surface, selected, connected_controllers):
        self._draw_background(surface)
        if self.assets:
            icon = pygame.transform.scale(self.assets.game_icon, (96, 96))
            surface.blit(icon, icon.get_rect(midtop=(surface.get_width() // 2, 22)))
        self._draw_title(surface)
        self._draw_options(surface, ("Play", "Controls", "Quit"), selected, 310)

        controller_text = f"Controllers connected: {connected_controllers}/3"
        self._center_text(surface, controller_text, self.small_font, (185, 210, 225), 530)
        self._center_text(
            surface,
            "Enter / A: Select     Up/Down: Navigate",
            self.small_font,
            (165, 185, 200),
            570,
        )

    def draw_pause_menu(self, surface, selected):
        self._draw_dim(surface)
        self._center_text(surface, "Paused", self.title_font, (255, 255, 255), 190)
        self._draw_options(surface, ("Resume", "Controls", "Main Menu", "Quit"), selected, 310)

    def draw_level_complete(self, surface):
        self._center_text(surface, "LEVEL COMPLETE!", self.title_font, (255, 222, 130), 230)
        self._center_text(surface, "The Forgotten Temple has been restored.", self.option_font, (235, 245, 245), 325)
        self._center_text(surface, "Press A, B, Enter, or Escape to return to the menu", self.small_font, (185, 210, 225), 420)

    def draw_game_over(self, surface):
        self._draw_dim(surface, alpha=170)
        self._center_text(surface, "GAME OVER", self.title_font, (255, 130, 110), 230)
        self._center_text(surface, "All three players have fallen.", self.option_font, (235, 235, 235), 325)
        self._center_text(surface, "Press A, B, Enter, Space, or Escape to try again", self.small_font, (185, 210, 225), 420)

    def draw_controls(self, surface, return_to_pause=False):
        logical_surface = pygame.Surface((WIDTH, HEIGHT))
        self._draw_controls(logical_surface, return_to_pause)
        scaled = pygame.transform.smoothscale(logical_surface, surface.get_size())
        surface.blit(scaled, (0, 0))

    def _draw_controls(self, surface, return_to_pause=False):
        self._draw_background(surface)
        width = surface.get_width()
        panel_top = 170
        panel_width = min(576, (width - 112) // 2)
        gap = 40
        keyboard_x = (width - panel_width * 2 - gap) // 2
        controller_x = keyboard_x + panel_width + gap
        panel_height = 450
        self._center_text(surface, "Controls", self.title_font, (255, 255, 255), 82)

        self._draw_controls_panel(surface, keyboard_x, panel_top, panel_width, panel_height, "KEYBOARD")
        self._draw_controls_panel(surface, controller_x, panel_top, panel_width, panel_height, "CONTROLLER")
        self._draw_keyboard_controls(surface, keyboard_x, panel_top, panel_width)
        self._draw_controller_controls(
            surface, controller_x, panel_top, panel_width
        )
        self._center_text(
            surface,
            "Enter / Space / Esc / controller B: return",
            self.control_hint_font,
            (165, 185, 200),
            656,
        )

    def _draw_controls_panel(self, surface, x, y, width, height, heading):
        panel = pygame.Rect(x, y, width, height)
        pygame.draw.rect(surface, (20, 29, 37), panel, border_radius=10)
        pygame.draw.rect(surface, (73, 112, 124), panel, width=2, border_radius=10)
        heading_surface = self.control_heading_font.render(
            heading, True, (170, 244, 241)
        )
        surface.blit(
            heading_surface,
            heading_surface.get_rect(center=(panel.centerx, y + 34)),
        )
        pygame.draw.line(
            surface, (75, 135, 145), (x + 22, y + 63), (x + width - 22, y + 63), 2
        )

    def _draw_keyboard_controls(self, surface, x, y, width):
        controls = (
            ("AQUA", "MOVE", "W  A  S  D", (80, 190, 255)),
            ("AQUA", "ACTIONS", "F Attack  ·  H Ability  ·  G Interact", (80, 190, 255)),
            ("IGNIS", "MOVE", "Arrow keys", (255, 145, 85)),
            ("IGNIS", "ACTIONS", "1 Attack  ·  2 Ability  ·  Num 3 Interact", (255, 145, 85)),
            ("TERRA", "MOVE", "I  J  K  L", (130, 215, 120)),
            ("TERRA", "ACTIONS", "O Attack  ·  P Ability  ·  U Interact", (130, 215, 120)),
            ("MAP", "TOGGLE", "M", (220, 234, 237)),
        )
        row_height = 43
        row_gap = 8
        start_y = y + 78
        for index, (player, action, binding, color) in enumerate(controls):
            row = pygame.Rect(
                x + 17,
                start_y + index * (row_height + row_gap),
                width - 34,
                row_height,
            )
            pygame.draw.rect(surface, (31, 43, 51), row, border_radius=5)
            label = self.control_label_font.render(
                f"{player}  {action}", True, color
            )
            value = self.control_value_font.render(binding, True, (220, 234, 237))
            surface.blit(label, label.get_rect(midleft=(row.x + 12, row.centery)))
            surface.blit(value, value.get_rect(midright=(row.right - 12, row.centery)))

    def _draw_controller_controls(self, surface, x, y, width):
        self._draw_gamepad(surface, (x + width // 2, y + 157))
        controls = (
            ("Move", "Left stick"),
            ("Attack", "A"),
            ("Ability", "X"),
            ("Interact", "Y"),
            ("Switch character (one pad)", "LB"),
            ("Toggle map", "Back / Select"),
            ("Pause", "Menu"),
        )
        row_height = 28
        row_gap = 4
        start_y = y + 253
        for index, (action, binding) in enumerate(controls):
            row = pygame.Rect(
                x + 18,
                start_y + index * (row_height + row_gap),
                width - 36,
                row_height,
            )
            label = self.control_label_font.render(action, True, (207, 220, 226))
            value = self.control_value_font.render(binding, True, (58, 211, 210))
            surface.blit(label, label.get_rect(midleft=(row.x + 4, row.centery)))
            surface.blit(value, value.get_rect(midright=(row.right - 4, row.centery)))

    def _draw_gamepad(self, surface, center):
        x, y = center
        outline = (134, 203, 205)
        body = [
            (x - 118, y - 25), (x - 94, y - 46), (x - 61, y - 45),
            (x - 28, y - 29), (x + 28, y - 29), (x + 61, y - 45),
            (x + 94, y - 46), (x + 118, y - 25), (x + 132, y + 32),
            (x + 120, y + 58), (x + 100, y + 65), (x + 77, y + 49),
            (x + 54, y + 18), (x - 54, y + 18), (x - 77, y + 49),
            (x - 100, y + 65), (x - 120, y + 58), (x - 132, y + 32),
        ]
        pygame.draw.polygon(surface, (13, 21, 28), body)
        pygame.draw.polygon(surface, outline, body, width=3)

        pygame.draw.rect(surface, (91, 131, 137), (x - 91, y - 4, 36, 12), border_radius=3)
        pygame.draw.rect(surface, (91, 131, 137), (x - 79, y - 16, 12, 36), border_radius=3)
        for stick_x in (x - 35, x + 25):
            pygame.draw.circle(surface, (48, 70, 76), (stick_x, y + 5), 14)
            pygame.draw.circle(surface, outline, (stick_x, y + 5), 14, 2)
            pygame.draw.circle(surface, (103, 148, 153), (stick_x, y + 5), 5)

        button_colors = {
            "A": (92, 207, 150),
            "X": (80, 190, 255),
            "Y": (255, 190, 95),
        }
        button_positions = {
            "Y": (x + 84, y - 19),
            "X": (x + 66, y + 1),
            "A": (x + 84, y + 21),
        }
        for name, position in button_positions.items():
            pygame.draw.circle(surface, button_colors[name], position, 10)
            button = self.control_hint_font.render(name, True, (17, 26, 31))
            surface.blit(button, button.get_rect(center=position))
        pygame.draw.circle(surface, (90, 116, 121), (x + 4, y - 10), 5)
        pygame.draw.circle(surface, (90, 116, 121), (x + 18, y - 10), 5)

    def draw_pause_hint(self, surface):
        self._draw_dim(surface, alpha=90)
        self._center_text(surface, "Paused - press Escape to resume", self.option_font, (255, 255, 255), 280)

    def _draw_background(self, surface):
        if self.assets:
            self.assets.draw_floor(surface)
            tint = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
            tint.fill((8, 20, 32, 150))
            surface.blit(tint, (0, 0))
        else:
            surface.fill((16, 27, 40))
            for index in range(12):
                x = 70 + index * 105
                color = (24 + index % 3 * 3, 43 + index % 4 * 3, 57 + index % 3 * 4)
                pygame.draw.circle(surface, color, (x, 600), 130)

    def _draw_title(self, surface):
        max_width = min(620, surface.get_width() - 120)
        scale = max_width / self.assets.title_logo.get_width()
        logo_size = (
            max_width,
            round(self.assets.title_logo.get_height() * scale),
        )
        logo = pygame.transform.smoothscale(self.assets.title_logo, logo_size)
        surface.blit(logo, logo.get_rect(midtop=(surface.get_width() // 2, 92)))

    def _draw_options(self, surface, options, selected, top):
        for index, option in enumerate(options):
            y = top + index * 58
            is_selected = index == selected
            color = (255, 222, 130) if is_selected else (205, 220, 230)
            text = self.option_font.render(option, True, color)
            rect = text.get_rect(center=(surface.get_width() // 2, y))
            if is_selected:
                backing = rect.inflate(54, 22)
                pygame.draw.rect(surface, (44, 67, 82), backing, border_radius=8)
                pygame.draw.rect(surface, (110, 178, 200), backing, width=2, border_radius=8)
                surface.blit(text, rect)
                marker = self.option_font.render(">", True, color)
                surface.blit(marker, (rect.left - 34, rect.top))
            else:
                surface.blit(text, rect)

    def _draw_dim(self, surface, alpha=190):
        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        overlay.fill((5, 10, 18, alpha))
        surface.blit(overlay, (0, 0))

    @staticmethod
    def _center_text(surface, text, font, color, y):
        rendered = font.render(text, True, color)
        surface.blit(rendered, (surface.get_width() // 2 - rendered.get_width() // 2, y))
